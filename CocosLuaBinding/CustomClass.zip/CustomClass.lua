
--------------------------------
-- @module CustomClass
-- @extend Ref
-- @parent_module 

--------------------------------
-- @function [parent=#CustomClass] init 
-- @param self
-- @return bool#bool ret (return value: bool)
        
--------------------------------
-- @function [parent=#CustomClass] helloMsg 
-- @param self
-- @return string#string ret (return value: string)
        
--------------------------------
-- @function [parent=#CustomClass] create 
-- @param self
-- @return CustomClass#CustomClass ret (return value: cc.CustomClass)
        
--------------------------------
-- @function [parent=#CustomClass] CustomClass 
-- @param self
        
return nil
