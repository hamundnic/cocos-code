
--------------------------------
-- @module TransitionShrinkGrow
-- @extend TransitionScene,TransitionEaseScene
-- @parent_module cc

--------------------------------
-- 
-- @function [parent=#TransitionShrinkGrow] easeActionWithAction 
-- @param self
-- @param #cc.ActionInterval action
-- @return ActionInterval#ActionInterval ret (return value: cc.ActionInterval)
        
--------------------------------
-- 
-- @function [parent=#TransitionShrinkGrow] create 
-- @param self
-- @param #float t
-- @param #cc.Scene scene
-- @return TransitionShrinkGrow#TransitionShrinkGrow ret (return value: cc.TransitionShrinkGrow)
        
return nil
