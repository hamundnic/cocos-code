
--------------------------------
-- @module RelativeBox
-- @extend Layout
-- @parent_module ccui

--------------------------------
-- @overload self, size_table         
-- @overload self         
-- @function [parent=#RelativeBox] create
-- @param self
-- @param #size_table size
-- @return RelativeBox#RelativeBox ret (retunr value: ccui.RelativeBox)

--------------------------------
-- Default constructor
-- @function [parent=#RelativeBox] RelativeBox 
-- @param self
        
return nil
