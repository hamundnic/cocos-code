
--------------------------------
-- @module BezierTo
-- @extend BezierBy
-- @parent_module cc

--------------------------------
-- 
-- @function [parent=#BezierTo] startWithTarget 
-- @param self
-- @param #cc.Node target
        
--------------------------------
-- 
-- @function [parent=#BezierTo] clone 
-- @param self
-- @return BezierTo#BezierTo ret (return value: cc.BezierTo)
        
--------------------------------
-- 
-- @function [parent=#BezierTo] reverse 
-- @param self
-- @return BezierTo#BezierTo ret (return value: cc.BezierTo)
  
	



--------------------------------
-- @function [parent=#BezierTo] create 
-- @param self
-- @param #double t
-- @param #point_table points
-- @return BezierTo#BezierTo ret (return value: cc.BezierTo)





return nil
