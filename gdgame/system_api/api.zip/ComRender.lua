
--------------------------------
-- @module ComRender
-- @extend Component
-- @parent_module ccs

--------------------------------
-- 
-- @function [parent=#ComRender] setNode 
-- @param self
-- @param #cc.Node node
        
--------------------------------
-- 
-- @function [parent=#ComRender] getNode 
-- @param self
-- @return Node#Node ret (return value: cc.Node)
        
--------------------------------
-- @overload self, cc.Node, char         
-- @overload self         
-- @function [parent=#ComRender] create
-- @param self
-- @param #cc.Node node
-- @param #char comName
-- @return ComRender#ComRender ret (retunr value: ccs.ComRender)

--------------------------------
-- 
-- @function [parent=#ComRender] createInstance 
-- @param self
-- @return Ref#Ref ret (return value: cc.Ref)
        
--------------------------------
-- 
-- @function [parent=#ComRender] serialize 
-- @param self
-- @param #void r
-- @return bool#bool ret (return value: bool)
        
return nil
