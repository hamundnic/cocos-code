
--------------------------------
-- @module EaseBounce
-- @extend ActionEase
-- @parent_module cc

--------------------------------
-- 
-- @function [parent=#EaseBounce] clone 
-- @param self
-- @return EaseBounce#EaseBounce ret (return value: cc.EaseBounce)
        
--------------------------------
-- 
-- @function [parent=#EaseBounce] reverse 
-- @param self
-- @return EaseBounce#EaseBounce ret (return value: cc.EaseBounce)
        
return nil
