
--------------------------------
-- @module TransitionProgressVertical
-- @extend TransitionProgress
-- @parent_module cc

--------------------------------
-- 
-- @function [parent=#TransitionProgressVertical] create 
-- @param self
-- @param #float t
-- @param #cc.Scene scene
-- @return TransitionProgressVertical#TransitionProgressVertical ret (return value: cc.TransitionProgressVertical)
        
return nil
