
--------------------------------
-- @module RotationFrame
-- @extend Frame
-- @parent_module ccs

--------------------------------
-- 
-- @function [parent=#RotationFrame] setRotation 
-- @param self
-- @param #float rotation
        
--------------------------------
-- 
-- @function [parent=#RotationFrame] getRotation 
-- @param self
-- @return float#float ret (return value: float)
        
--------------------------------
-- 
-- @function [parent=#RotationFrame] create 
-- @param self
-- @return RotationFrame#RotationFrame ret (return value: ccs.RotationFrame)
        
--------------------------------
-- 
-- @function [parent=#RotationFrame] apply 
-- @param self
-- @param #float percent
        
--------------------------------
-- 
-- @function [parent=#RotationFrame] clone 
-- @param self
-- @return Frame#Frame ret (return value: ccs.Frame)
        
--------------------------------
-- 
-- @function [parent=#RotationFrame] RotationFrame 
-- @param self
        
return nil
