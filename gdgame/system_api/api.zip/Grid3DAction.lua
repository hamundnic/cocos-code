
--------------------------------
-- @module Grid3DAction
-- @extend GridAction
-- @parent_module cc

--------------------------------
--  returns the grid 
-- @function [parent=#Grid3DAction] getGrid 
-- @param self
-- @return GridBase#GridBase ret (return value: cc.GridBase)
        
--------------------------------
-- 
-- @function [parent=#Grid3DAction] clone 
-- @param self
-- @return Grid3DAction#Grid3DAction ret (return value: cc.Grid3DAction)
        
return nil
