
--------------------------------
-- @module EaseCubicActionIn
-- @extend ActionEase
-- @parent_module cc

--------------------------------
--  creates the action 
-- @function [parent=#EaseCubicActionIn] create 
-- @param self
-- @param #cc.ActionInterval action
-- @return EaseCubicActionIn#EaseCubicActionIn ret (return value: cc.EaseCubicActionIn)
        
--------------------------------
-- 
-- @function [parent=#EaseCubicActionIn] clone 
-- @param self
-- @return EaseCubicActionIn#EaseCubicActionIn ret (return value: cc.EaseCubicActionIn)
        
--------------------------------
-- 
-- @function [parent=#EaseCubicActionIn] update 
-- @param self
-- @param #float time
        
--------------------------------
-- 
-- @function [parent=#EaseCubicActionIn] reverse 
-- @param self
-- @return EaseCubicActionIn#EaseCubicActionIn ret (return value: cc.EaseCubicActionIn)
        
return nil
