
--------------------------------
-- @module ParticleSmoke
-- @extend ParticleSystemQuad
-- @parent_module cc

--------------------------------
-- 
-- @function [parent=#ParticleSmoke] create 
-- @param self
-- @return ParticleSmoke#ParticleSmoke ret (return value: cc.ParticleSmoke)
        
--------------------------------
-- 
-- @function [parent=#ParticleSmoke] createWithTotalParticles 
-- @param self
-- @param #int numberOfParticles
-- @return ParticleSmoke#ParticleSmoke ret (return value: cc.ParticleSmoke)
        
return nil
