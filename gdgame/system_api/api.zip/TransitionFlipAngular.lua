
--------------------------------
-- @module TransitionFlipAngular
-- @extend TransitionSceneOriented
-- @parent_module cc

--------------------------------
-- @overload self, float, cc.Scene         
-- @overload self, float, cc.Scene, int         
-- @function [parent=#TransitionFlipAngular] create
-- @param self
-- @param #float t
-- @param #cc.Scene s
-- @param #int o
-- @return TransitionFlipAngular#TransitionFlipAngular ret (retunr value: cc.TransitionFlipAngular)

return nil
