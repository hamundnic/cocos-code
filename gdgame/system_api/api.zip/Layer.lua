
--------------------------------
-- @module Layer
-- @extend Node
-- @parent_module cc

--------------------------------
--  creates a fullscreen black layer 
-- @function [parent=#Layer] create 
-- @param self
-- @return Layer#Layer ret (return value: cc.Layer)
        
--------------------------------
-- 
-- @function [parent=#Layer] getDescription 
-- @param self
-- @return string#string ret (return value: string)
        
return nil
