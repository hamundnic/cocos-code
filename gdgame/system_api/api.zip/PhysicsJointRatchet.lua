
--------------------------------
-- @module PhysicsJointRatchet
-- @extend PhysicsJoint
-- @parent_module cc

--------------------------------
-- 
-- @function [parent=#PhysicsJointRatchet] getAngle 
-- @param self
-- @return float#float ret (return value: float)
        
--------------------------------
-- 
-- @function [parent=#PhysicsJointRatchet] setAngle 
-- @param self
-- @param #float angle
        
--------------------------------
-- 
-- @function [parent=#PhysicsJointRatchet] setPhase 
-- @param self
-- @param #float phase
        
--------------------------------
-- 
-- @function [parent=#PhysicsJointRatchet] getPhase 
-- @param self
-- @return float#float ret (return value: float)
        
--------------------------------
-- 
-- @function [parent=#PhysicsJointRatchet] setRatchet 
-- @param self
-- @param #float ratchet
        
--------------------------------
-- 
-- @function [parent=#PhysicsJointRatchet] getRatchet 
-- @param self
-- @return float#float ret (return value: float)
        
--------------------------------
-- 
-- @function [parent=#PhysicsJointRatchet] construct 
-- @param self
-- @param #cc.PhysicsBody a
-- @param #cc.PhysicsBody b
-- @param #float phase
-- @param #float ratchet
-- @return PhysicsJointRatchet#PhysicsJointRatchet ret (return value: cc.PhysicsJointRatchet)
        
return nil
