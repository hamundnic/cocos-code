
--------------------------------
-- @module TransitionZoomFlipY
-- @extend TransitionSceneOriented
-- @parent_module cc

--------------------------------
-- @overload self, float, cc.Scene         
-- @overload self, float, cc.Scene, int         
-- @function [parent=#TransitionZoomFlipY] create
-- @param self
-- @param #float t
-- @param #cc.Scene s
-- @param #int o
-- @return TransitionZoomFlipY#TransitionZoomFlipY ret (retunr value: cc.TransitionZoomFlipY)

return nil
