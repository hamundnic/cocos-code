
--------------------------------
-- @module FadeOutUpTiles
-- @extend FadeOutTRTiles
-- @parent_module cc

--------------------------------
-- 
-- @function [parent=#FadeOutUpTiles] transformTile 
-- @param self
-- @param #vec2_table pos
-- @param #float distance
        
--------------------------------
--  creates the action with the grid size and the duration 
-- @function [parent=#FadeOutUpTiles] create 
-- @param self
-- @param #float duration
-- @param #size_table gridSize
-- @return FadeOutUpTiles#FadeOutUpTiles ret (return value: cc.FadeOutUpTiles)
        
--------------------------------
-- 
-- @function [parent=#FadeOutUpTiles] clone 
-- @param self
-- @return FadeOutUpTiles#FadeOutUpTiles ret (return value: cc.FadeOutUpTiles)
        
--------------------------------
-- 
-- @function [parent=#FadeOutUpTiles] testFunc 
-- @param self
-- @param #size_table pos
-- @param #float time
-- @return float#float ret (return value: float)
        
return nil
