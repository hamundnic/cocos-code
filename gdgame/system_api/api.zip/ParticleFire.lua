
--------------------------------
-- @module ParticleFire
-- @extend ParticleSystemQuad
-- @parent_module cc

--------------------------------
-- 
-- @function [parent=#ParticleFire] create 
-- @param self
-- @return ParticleFire#ParticleFire ret (return value: cc.ParticleFire)
        
--------------------------------
-- 
-- @function [parent=#ParticleFire] createWithTotalParticles 
-- @param self
-- @param #int numberOfParticles
-- @return ParticleFire#ParticleFire ret (return value: cc.ParticleFire)
        
return nil
