--------------------------------
-- @module ResolutionPolicy

--------------------------------------------------------
-- the ResolutionPolicy EXACT_FIT
-- @field [parent=#ResolutionPolicy] int#int EXACT_FIT preloaded module

--------------------------------------------------------
-- the ResolutionPolicy NO_BORDER
-- @field [parent=#ResolutionPolicy] int#int NO_BORDER preloaded module

--------------------------------------------------------
-- the ResolutionPolicy SHOW_ALL
-- @field [parent=#ResolutionPolicy] int#int SHOW_ALL preloaded module

--------------------------------------------------------
-- the ResolutionPolicy FIXED_HEIGHT
-- @field [parent=#ResolutionPolicy] int#int FIXED_HEIGHT preloaded module

--------------------------------------------------------
-- the ResolutionPolicy FIXED_WIDTH
-- @field [parent=#ResolutionPolicy] int#int FIXED_WIDTH preloaded module

--------------------------------------------------------
-- the ResolutionPolicy UNKNOWN
-- @field [parent=#ResolutionPolicy] int#int UNKNOWN preloaded module

return nil