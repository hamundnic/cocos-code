
--------------------------------
-- @module ObjectFactory
-- @parent_module ccs

--------------------------------------------------------
-- the TInfo _typeMap
-- @field [parent=#ObjectFactory] table#table _typeMap preloaded module

--------------------------------------------------------
-- the TInfo _instance
-- @field [parent=#ObjectFactory] ObjectFactory#ObjectFactory _instance preloaded module

--------------------------------
-- @function [parent=#ObjectFactory] new
-- @return table#table ret (return value: table)

--------------------------------
-- @function [parent=#ObjectFactory] getInstance
-- @return table#table ret (return value: table)

--------------------------------
-- @function [parent=#ObjectFactory] destroyInstance

--------------------------------
-- @function [parent=#ObjectFactory] registerType
-- @param #table t

return nil