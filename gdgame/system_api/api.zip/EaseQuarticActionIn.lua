
--------------------------------
-- @module EaseQuarticActionIn
-- @extend ActionEase
-- @parent_module cc

--------------------------------
--  creates the action 
-- @function [parent=#EaseQuarticActionIn] create 
-- @param self
-- @param #cc.ActionInterval action
-- @return EaseQuarticActionIn#EaseQuarticActionIn ret (return value: cc.EaseQuarticActionIn)
        
--------------------------------
-- 
-- @function [parent=#EaseQuarticActionIn] clone 
-- @param self
-- @return EaseQuarticActionIn#EaseQuarticActionIn ret (return value: cc.EaseQuarticActionIn)
        
--------------------------------
-- 
-- @function [parent=#EaseQuarticActionIn] update 
-- @param self
-- @param #float time
        
--------------------------------
-- 
-- @function [parent=#EaseQuarticActionIn] reverse 
-- @param self
-- @return EaseQuarticActionIn#EaseQuarticActionIn ret (return value: cc.EaseQuarticActionIn)
        
return nil
