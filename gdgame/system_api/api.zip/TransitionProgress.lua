
--------------------------------
-- @module TransitionProgress
-- @extend TransitionScene
-- @parent_module cc

--------------------------------
-- 
-- @function [parent=#TransitionProgress] create 
-- @param self
-- @param #float t
-- @param #cc.Scene scene
-- @return TransitionProgress#TransitionProgress ret (return value: cc.TransitionProgress)
        
return nil
