
--------------------------------
-- @module FlipX
-- @extend ActionInstant
-- @parent_module cc

--------------------------------
--  create the action 
-- @function [parent=#FlipX] create 
-- @param self
-- @param #bool x
-- @return FlipX#FlipX ret (return value: cc.FlipX)
        
--------------------------------
-- 
-- @function [parent=#FlipX] clone 
-- @param self
-- @return FlipX#FlipX ret (return value: cc.FlipX)
        
--------------------------------
-- 
-- @function [parent=#FlipX] update 
-- @param self
-- @param #float time
        
--------------------------------
-- 
-- @function [parent=#FlipX] reverse 
-- @param self
-- @return FlipX#FlipX ret (return value: cc.FlipX)
        
return nil
