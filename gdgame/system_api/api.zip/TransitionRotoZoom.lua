
--------------------------------
-- @module TransitionRotoZoom
-- @extend TransitionScene
-- @parent_module cc

--------------------------------
-- 
-- @function [parent=#TransitionRotoZoom] create 
-- @param self
-- @param #float t
-- @param #cc.Scene scene
-- @return TransitionRotoZoom#TransitionRotoZoom ret (return value: cc.TransitionRotoZoom)
        
return nil
