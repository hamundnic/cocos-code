
--------------------------------
-- @module EventKeyboard
-- @extend Event
-- @parent_module cc

--------------------------------
-- 
-- @function [parent=#EventKeyboard] EventKeyboard 
-- @param self
-- @param #int keyCode
-- @param #bool isPressed
        
return nil
