
--------------------------------
-- @module GLNode
-- @parent_module cc

--------------------------------
-- @function [parent=#GLNode] create 
-- @param self
-- @return GLNode#GLNode GLNode ret (return value: cc.GLNode)

--------------------------------
-- @function [parent=#GLNode] setShaderProgram 
-- @param self
-- @param GLProgram#GLProgram GLProgram
-- @return GLNode#GLNode GLNode ret (return value: cc.GLNode)

return nil
