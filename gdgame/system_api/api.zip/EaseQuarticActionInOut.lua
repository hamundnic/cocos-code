
--------------------------------
-- @module EaseQuarticActionInOut
-- @extend ActionEase
-- @parent_module cc

--------------------------------
--  creates the action 
-- @function [parent=#EaseQuarticActionInOut] create 
-- @param self
-- @param #cc.ActionInterval action
-- @return EaseQuarticActionInOut#EaseQuarticActionInOut ret (return value: cc.EaseQuarticActionInOut)
        
--------------------------------
-- 
-- @function [parent=#EaseQuarticActionInOut] clone 
-- @param self
-- @return EaseQuarticActionInOut#EaseQuarticActionInOut ret (return value: cc.EaseQuarticActionInOut)
        
--------------------------------
-- 
-- @function [parent=#EaseQuarticActionInOut] update 
-- @param self
-- @param #float time
        
--------------------------------
-- 
-- @function [parent=#EaseQuarticActionInOut] reverse 
-- @param self
-- @return EaseQuarticActionInOut#EaseQuarticActionInOut ret (return value: cc.EaseQuarticActionInOut)
        
return nil
