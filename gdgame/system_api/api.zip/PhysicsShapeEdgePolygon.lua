
--------------------------------
-- @module PhysicsShapeEdgePolygon
-- @extend PhysicsShape
-- @parent_module cc

--------------------------------
-- 
-- @function [parent=#PhysicsShapeEdgePolygon] getPointsCount 
-- @param self
-- @return int#int ret (return value: int)
        
--------------------------------
-- 
-- @function [parent=#PhysicsShapeEdgePolygon] getCenter 
-- @param self
-- @return vec2_table#vec2_table ret (return value: vec2_table)
        
return nil
