
--------------------------------
-- @module EaseBounceIn
-- @extend EaseBounce
-- @parent_module cc

--------------------------------
--  creates the action 
-- @function [parent=#EaseBounceIn] create 
-- @param self
-- @param #cc.ActionInterval action
-- @return EaseBounceIn#EaseBounceIn ret (return value: cc.EaseBounceIn)
        
--------------------------------
-- 
-- @function [parent=#EaseBounceIn] clone 
-- @param self
-- @return EaseBounceIn#EaseBounceIn ret (return value: cc.EaseBounceIn)
        
--------------------------------
-- 
-- @function [parent=#EaseBounceIn] update 
-- @param self
-- @param #float time
        
--------------------------------
-- 
-- @function [parent=#EaseBounceIn] reverse 
-- @param self
-- @return EaseBounce#EaseBounce ret (return value: cc.EaseBounce)
        
return nil
