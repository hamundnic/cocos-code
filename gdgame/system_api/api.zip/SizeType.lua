
--------------------------------
-- @module SizeType
-- @parent_module ccui

--------------------------------------------------------
-- the SizeType absolute
-- @field [parent=#SizeType] int#int absolute preloaded module

--------------------------------------------------------
-- the SizeType percent
-- @field [parent=#SizeType] int#int percent preloaded module

return nil
