
--------------------------------
-- @module Skeleton
-- @extend Node,BlendProtocol
-- @parent_module sp

--------------------------------
-- 
-- @function [parent=#Skeleton] setToSetupPose 
-- @param self
        
--------------------------------
-- 
-- @function [parent=#Skeleton] setBlendFunc 
-- @param self
-- @param #cc.BlendFunc func
        
--------------------------------
-- 
-- @function [parent=#Skeleton] onDraw 
-- @param self
-- @param #mat4_table transform
-- @param #unsigned int flags
        
--------------------------------
-- 
-- @function [parent=#Skeleton] setSlotsToSetupPose 
-- @param self
        
--------------------------------
-- 
-- @function [parent=#Skeleton] getBlendFunc 
-- @param self
-- @return BlendFunc#BlendFunc ret (return value: cc.BlendFunc)
        
--------------------------------
-- 
-- @function [parent=#Skeleton] setSkin 
-- @param self
-- @param #char skinName
-- @return bool#bool ret (return value: bool)
        
--------------------------------
-- 
-- @function [parent=#Skeleton] setBonesToSetupPose 
-- @param self
        
--------------------------------
-- 
-- @function [parent=#Skeleton] getBoundingBox 
-- @param self
-- @return rect_table#rect_table ret (return value: rect_table)
        
--------------------------------
-- 
-- @function [parent=#Skeleton] onEnter 
-- @param self
        
--------------------------------
-- 
-- @function [parent=#Skeleton] onExit 
-- @param self
        
return nil
