
--------------------------------
-- @module EaseQuinticActionInOut
-- @extend ActionEase
-- @parent_module cc

--------------------------------
--  creates the action 
-- @function [parent=#EaseQuinticActionInOut] create 
-- @param self
-- @param #cc.ActionInterval action
-- @return EaseQuinticActionInOut#EaseQuinticActionInOut ret (return value: cc.EaseQuinticActionInOut)
        
--------------------------------
-- 
-- @function [parent=#EaseQuinticActionInOut] clone 
-- @param self
-- @return EaseQuinticActionInOut#EaseQuinticActionInOut ret (return value: cc.EaseQuinticActionInOut)
        
--------------------------------
-- 
-- @function [parent=#EaseQuinticActionInOut] update 
-- @param self
-- @param #float time
        
--------------------------------
-- 
-- @function [parent=#EaseQuinticActionInOut] reverse 
-- @param self
-- @return EaseQuinticActionInOut#EaseQuinticActionInOut ret (return value: cc.EaseQuinticActionInOut)
        
return nil
