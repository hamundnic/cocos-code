
--------------------------------
-- @module RichElementText
-- @extend RichElement
-- @parent_module ccui

--------------------------------
-- 
-- @function [parent=#RichElementText] init 
-- @param self
-- @param #int tag
-- @param #color3b_table color
-- @param #unsigned char opacity
-- @param #string text
-- @param #string fontName
-- @param #float fontSize
-- @return bool#bool ret (return value: bool)
        
--------------------------------
-- 
-- @function [parent=#RichElementText] create 
-- @param self
-- @param #int tag
-- @param #color3b_table color
-- @param #unsigned char opacity
-- @param #string text
-- @param #string fontName
-- @param #float fontSize
-- @return RichElementText#RichElementText ret (return value: ccui.RichElementText)
        
--------------------------------
-- 
-- @function [parent=#RichElementText] RichElementText 
-- @param self
        
return nil
