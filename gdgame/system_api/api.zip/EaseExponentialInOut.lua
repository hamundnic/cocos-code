
--------------------------------
-- @module EaseExponentialInOut
-- @extend ActionEase
-- @parent_module cc

--------------------------------
--  creates the action 
-- @function [parent=#EaseExponentialInOut] create 
-- @param self
-- @param #cc.ActionInterval action
-- @return EaseExponentialInOut#EaseExponentialInOut ret (return value: cc.EaseExponentialInOut)
        
--------------------------------
-- 
-- @function [parent=#EaseExponentialInOut] clone 
-- @param self
-- @return EaseExponentialInOut#EaseExponentialInOut ret (return value: cc.EaseExponentialInOut)
        
--------------------------------
-- 
-- @function [parent=#EaseExponentialInOut] update 
-- @param self
-- @param #float time
        
--------------------------------
-- 
-- @function [parent=#EaseExponentialInOut] reverse 
-- @param self
-- @return EaseExponentialInOut#EaseExponentialInOut ret (return value: cc.EaseExponentialInOut)
        
return nil
