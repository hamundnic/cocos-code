
--------------------------------
-- @module TransitionSlideInR
-- @extend TransitionSlideInL
-- @parent_module cc

--------------------------------
--  returns the action that will be performed by the incoming and outgoing scene 
-- @function [parent=#TransitionSlideInR] action 
-- @param self
-- @return ActionInterval#ActionInterval ret (return value: cc.ActionInterval)
        
--------------------------------
-- 
-- @function [parent=#TransitionSlideInR] create 
-- @param self
-- @param #float t
-- @param #cc.Scene scene
-- @return TransitionSlideInR#TransitionSlideInR ret (return value: cc.TransitionSlideInR)
        
return nil
