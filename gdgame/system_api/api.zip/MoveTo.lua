
--------------------------------
-- @module MoveTo
-- @extend MoveBy
-- @parent_module cc

--------------------------------
--  creates the action 
-- @function [parent=#MoveTo] create 
-- @param self
-- @param #float duration
-- @param #vec2_table position
-- @return MoveTo#MoveTo ret (return value: cc.MoveTo)
        
--------------------------------
-- 
-- @function [parent=#MoveTo] startWithTarget 
-- @param self
-- @param #cc.Node target
        
--------------------------------
-- 
-- @function [parent=#MoveTo] clone 
-- @param self
-- @return MoveTo#MoveTo ret (return value: cc.MoveTo)
        
return nil
