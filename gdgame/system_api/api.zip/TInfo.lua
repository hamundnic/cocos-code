
--------------------------------
-- @module TInfo
-- @parent_module ccs

--------------------------------
-- @function [parent=#TInfo] new
-- @param #string className
-- @param #function handler
-- @return table#table ret (return value: table)

return nil
