
--------------------------------
-- @module TransitionProgressRadialCW
-- @extend TransitionProgress
-- @parent_module cc

--------------------------------
-- 
-- @function [parent=#TransitionProgressRadialCW] create 
-- @param self
-- @param #float t
-- @param #cc.Scene scene
-- @return TransitionProgressRadialCW#TransitionProgressRadialCW ret (return value: cc.TransitionProgressRadialCW)
        
return nil
