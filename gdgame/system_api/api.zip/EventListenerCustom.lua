
--------------------------------
-- @module EventListenerCustom
-- @extend EventListener
-- @parent_module cc

--------------------------------
-- 
-- @function [parent=#EventListenerCustom] clone 
-- @param self
-- @return EventListenerCustom#EventListenerCustom ret (return value: cc.EventListenerCustom)
        
--------------------------------
-- / Overrides
-- @function [parent=#EventListenerCustom] checkAvailable 
-- @param self
-- @return bool#bool ret (return value: bool)
 
	



--------------------------------
-- @overload self        
-- @overload self, eventName, handler
-- @function [parent=#EventListenerCustom] create 
-- @param self
-- @param #string eventName
-- @param #function handler
-- @return EventListenerCustom#EventListenerCustom ret (return value: cc.EventListenerCustom)





return nil
