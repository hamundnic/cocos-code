
--------------------------------
-- @module vec3_table

--------------------------------------------------------
-- the vec3_table x 
-- @field [parent=#vec3_table] #float x preloaded module

--------------------------------------------------------
-- the vec3_table y 
-- @field [parent=#vec3_table] #float y preloaded module

--------------------------------------------------------
-- the vec3_table z 
-- @field [parent=#vec3_table] #float z preloaded module

return nil
