
--------------------------------
-- @module FadeIn
-- @extend FadeTo
-- @parent_module cc

--------------------------------
-- 
-- @function [parent=#FadeIn] setReverseAction 
-- @param self
-- @param #cc.FadeTo ac
        
--------------------------------
--  creates the action 
-- @function [parent=#FadeIn] create 
-- @param self
-- @param #float d
-- @return FadeIn#FadeIn ret (return value: cc.FadeIn)
        
--------------------------------
-- 
-- @function [parent=#FadeIn] startWithTarget 
-- @param self
-- @param #cc.Node target
        
--------------------------------
-- 
-- @function [parent=#FadeIn] clone 
-- @param self
-- @return FadeIn#FadeIn ret (return value: cc.FadeIn)
        
--------------------------------
-- 
-- @function [parent=#FadeIn] reverse 
-- @param self
-- @return FadeTo#FadeTo ret (return value: cc.FadeTo)
        
return nil
