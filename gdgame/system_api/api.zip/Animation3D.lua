
--------------------------------
-- @module Animation3D
-- @extend Ref
-- @parent_module cc

--------------------------------
-- get duration
-- @function [parent=#Animation3D] getDuration 
-- @param self
-- @return float#float ret (return value: float)
        
--------------------------------
-- read all animation or only the animation with given animationName? animationName == "" read the first.
-- @function [parent=#Animation3D] create 
-- @param self
-- @param #string filename
-- @param #string animationName
-- @return Animation3D#Animation3D ret (return value: cc.Animation3D)
        
return nil
