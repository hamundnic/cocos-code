
--------------------------------
-- @module RotationSkewFrame
-- @extend SkewFrame
-- @parent_module ccs

--------------------------------
-- 
-- @function [parent=#RotationSkewFrame] create 
-- @param self
-- @return RotationSkewFrame#RotationSkewFrame ret (return value: ccs.RotationSkewFrame)
        
--------------------------------
-- 
-- @function [parent=#RotationSkewFrame] apply 
-- @param self
-- @param #float percent
        
--------------------------------
-- 
-- @function [parent=#RotationSkewFrame] clone 
-- @param self
-- @return Frame#Frame ret (return value: ccs.Frame)
        
--------------------------------
-- 
-- @function [parent=#RotationSkewFrame] RotationSkewFrame 
-- @param self
        
return nil
