
--------------------------------
-- @module EaseQuadraticActionInOut
-- @extend ActionEase
-- @parent_module cc

--------------------------------
--  creates the action 
-- @function [parent=#EaseQuadraticActionInOut] create 
-- @param self
-- @param #cc.ActionInterval action
-- @return EaseQuadraticActionInOut#EaseQuadraticActionInOut ret (return value: cc.EaseQuadraticActionInOut)
        
--------------------------------
-- 
-- @function [parent=#EaseQuadraticActionInOut] clone 
-- @param self
-- @return EaseQuadraticActionInOut#EaseQuadraticActionInOut ret (return value: cc.EaseQuadraticActionInOut)
        
--------------------------------
-- 
-- @function [parent=#EaseQuadraticActionInOut] update 
-- @param self
-- @param #float time
        
--------------------------------
-- 
-- @function [parent=#EaseQuadraticActionInOut] reverse 
-- @param self
-- @return EaseQuadraticActionInOut#EaseQuadraticActionInOut ret (return value: cc.EaseQuadraticActionInOut)
        
return nil
