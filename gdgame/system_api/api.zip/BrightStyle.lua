--------------------------------
-- @module BrightStyle
-- @parent_module ccui

--------------------------------------------------------
-- the BrightStyle none
-- @field [parent=#BrightStyle] int#int none preloaded module

--------------------------------------------------------
-- the BrightStyle normal
-- @field [parent=#BrightStyle] int#int normal preloaded module

--------------------------------------------------------
-- the BrightStyle highlight
-- @field [parent=#BrightStyle] int#int highlight preloaded module

return nil