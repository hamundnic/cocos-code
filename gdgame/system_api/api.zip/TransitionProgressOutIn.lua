
--------------------------------
-- @module TransitionProgressOutIn
-- @extend TransitionProgress
-- @parent_module cc

--------------------------------
-- 
-- @function [parent=#TransitionProgressOutIn] create 
-- @param self
-- @param #float t
-- @param #cc.Scene scene
-- @return TransitionProgressOutIn#TransitionProgressOutIn ret (return value: cc.TransitionProgressOutIn)
        
return nil
