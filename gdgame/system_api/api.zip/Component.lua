
--------------------------------
-- @module Component
-- @extend Ref
-- @parent_module cc

--------------------------------
-- 
-- @function [parent=#Component] setEnabled 
-- @param self
-- @param #bool b
        
--------------------------------
-- 
-- @function [parent=#Component] setName 
-- @param self
-- @param #string name
        
--------------------------------
-- 
-- @function [parent=#Component] isEnabled 
-- @param self
-- @return bool#bool ret (return value: bool)
        
--------------------------------
-- 
-- @function [parent=#Component] update 
-- @param self
-- @param #float delta
        
--------------------------------
-- 
-- @function [parent=#Component] getOwner 
-- @param self
-- @return Node#Node ret (return value: cc.Node)
        
--------------------------------
-- 
-- @function [parent=#Component] init 
-- @param self
-- @return bool#bool ret (return value: bool)
        
--------------------------------
-- 
-- @function [parent=#Component] setOwner 
-- @param self
-- @param #cc.Node pOwner
        
--------------------------------
-- 
-- @function [parent=#Component] getName 
-- @param self
-- @return string#string ret (return value: string)
        
--------------------------------
-- 
-- @function [parent=#Component] create 
-- @param self
-- @return Component#Component ret (return value: cc.Component)
        
return nil
