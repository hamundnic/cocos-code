
--------------------------------
-- @module HBox
-- @extend Layout
-- @parent_module ccui

--------------------------------
-- @overload self, size_table         
-- @overload self         
-- @function [parent=#HBox] create
-- @param self
-- @param #size_table size
-- @return HBox#HBox ret (retunr value: ccui.HBox)

--------------------------------
-- Default constructor
-- @function [parent=#HBox] HBox 
-- @param self
        
return nil
