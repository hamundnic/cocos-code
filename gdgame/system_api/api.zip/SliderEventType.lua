
--------------------------------
-- @module SliderEventType
-- @parent_module ccui

--------------------------------------------------------
-- the SliderEventType percentChanged
-- @field [parent=#SliderEventType] int#int percentChanged preloaded module

return nil