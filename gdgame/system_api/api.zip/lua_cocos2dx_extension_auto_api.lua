--------------------------------
-- @module cc

--------------------------------------------------------
-- the cc Scale9Sprite
-- @field [parent=#cc] Scale9Sprite#Scale9Sprite Scale9Sprite preloaded module


--------------------------------------------------------
-- the cc Control
-- @field [parent=#cc] Control#Control Control preloaded module


--------------------------------------------------------
-- the cc ControlButton
-- @field [parent=#cc] ControlButton#ControlButton ControlButton preloaded module


--------------------------------------------------------
-- the cc ControlHuePicker
-- @field [parent=#cc] ControlHuePicker#ControlHuePicker ControlHuePicker preloaded module


--------------------------------------------------------
-- the cc ControlSaturationBrightnessPicker
-- @field [parent=#cc] ControlSaturationBrightnessPicker#ControlSaturationBrightnessPicker ControlSaturationBrightnessPicker preloaded module


--------------------------------------------------------
-- the cc ControlColourPicker
-- @field [parent=#cc] ControlColourPicker#ControlColourPicker ControlColourPicker preloaded module


--------------------------------------------------------
-- the cc ControlPotentiometer
-- @field [parent=#cc] ControlPotentiometer#ControlPotentiometer ControlPotentiometer preloaded module


--------------------------------------------------------
-- the cc ControlSlider
-- @field [parent=#cc] ControlSlider#ControlSlider ControlSlider preloaded module


--------------------------------------------------------
-- the cc ControlStepper
-- @field [parent=#cc] ControlStepper#ControlStepper ControlStepper preloaded module


--------------------------------------------------------
-- the cc ControlSwitch
-- @field [parent=#cc] ControlSwitch#ControlSwitch ControlSwitch preloaded module


--------------------------------------------------------
-- the cc ScrollView
-- @field [parent=#cc] ScrollView#ScrollView ScrollView preloaded module


--------------------------------------------------------
-- the cc TableViewCell
-- @field [parent=#cc] TableViewCell#TableViewCell TableViewCell preloaded module


--------------------------------------------------------
-- the cc TableView
-- @field [parent=#cc] TableView#TableView TableView preloaded module


--------------------------------------------------------
-- the cc EditBox
-- @field [parent=#cc] EditBox#EditBox EditBox preloaded module


--------------------------------------------------------
-- the cc AssetsManager
-- @field [parent=#cc] AssetsManager#AssetsManager AssetsManager preloaded module


--------------------------------------------------------
-- the cc CCBAnimationManager
-- @field [parent=#cc] CCBAnimationManager#CCBAnimationManager CCBAnimationManager preloaded module


--------------------------------------------------------
-- the cc CCBReader
-- @field [parent=#cc] CCBReader#CCBReader CCBReader preloaded module


return nil
