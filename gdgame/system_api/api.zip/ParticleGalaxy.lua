
--------------------------------
-- @module ParticleGalaxy
-- @extend ParticleSystemQuad
-- @parent_module cc

--------------------------------
-- 
-- @function [parent=#ParticleGalaxy] create 
-- @param self
-- @return ParticleGalaxy#ParticleGalaxy ret (return value: cc.ParticleGalaxy)
        
--------------------------------
-- 
-- @function [parent=#ParticleGalaxy] createWithTotalParticles 
-- @param self
-- @param #int numberOfParticles
-- @return ParticleGalaxy#ParticleGalaxy ret (return value: cc.ParticleGalaxy)
        
return nil
