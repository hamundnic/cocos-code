
--------------------------------
-- @module RichElementCustomNode
-- @extend RichElement
-- @parent_module ccui

--------------------------------
-- 
-- @function [parent=#RichElementCustomNode] init 
-- @param self
-- @param #int tag
-- @param #color3b_table color
-- @param #unsigned char opacity
-- @param #cc.Node customNode
-- @return bool#bool ret (return value: bool)
        
--------------------------------
-- 
-- @function [parent=#RichElementCustomNode] create 
-- @param self
-- @param #int tag
-- @param #color3b_table color
-- @param #unsigned char opacity
-- @param #cc.Node customNode
-- @return RichElementCustomNode#RichElementCustomNode ret (return value: ccui.RichElementCustomNode)
        
--------------------------------
-- 
-- @function [parent=#RichElementCustomNode] RichElementCustomNode 
-- @param self
        
return nil
