
--------------------------------
-- @module ListViewGravity
-- @parent_module ccui

--------------------------------------------------------
-- the ListViewGravity left
-- @field [parent=#ListViewGravity] int#int left preloaded module

--------------------------------------------------------
-- the ListViewGravity right
-- @field [parent=#ListViewGravity] int#int right preloaded module

--------------------------------------------------------
-- the ListViewGravity centerHorizontal
-- @field [parent=#ListViewGravity] int#int centerHorizontal preloaded module

--------------------------------------------------------
-- the ListViewGravity top
-- @field [parent=#ListViewGravity] int#int top preloaded module

--------------------------------------------------------
-- the ListViewGravity bottom
-- @field [parent=#ListViewGravity] int#int bottom preloaded module

--------------------------------------------------------
-- the ListViewGravity centerVertical
-- @field [parent=#ListViewGravity] int#int centerVertical preloaded module

return nil