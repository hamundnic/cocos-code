
--------------------------------
-- @module TransitionMoveInT
-- @extend TransitionMoveInL
-- @parent_module cc

--------------------------------
-- 
-- @function [parent=#TransitionMoveInT] create 
-- @param self
-- @param #float t
-- @param #cc.Scene scene
-- @return TransitionMoveInT#TransitionMoveInT ret (return value: cc.TransitionMoveInT)
        
return nil
