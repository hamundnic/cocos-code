
--------------------------------
-- @module TransitionFadeDown
-- @extend TransitionFadeTR
-- @parent_module cc

--------------------------------
-- 
-- @function [parent=#TransitionFadeDown] create 
-- @param self
-- @param #float t
-- @param #cc.Scene scene
-- @return TransitionFadeDown#TransitionFadeDown ret (return value: cc.TransitionFadeDown)
        
--------------------------------
-- 
-- @function [parent=#TransitionFadeDown] actionWithSize 
-- @param self
-- @param #size_table size
-- @return ActionInterval#ActionInterval ret (return value: cc.ActionInterval)
        
return nil
