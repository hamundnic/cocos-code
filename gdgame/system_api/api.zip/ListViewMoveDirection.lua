
--------------------------------
-- @module ListViewMoveDirection
-- @parent_module ccui

--------------------------------------------------------
-- the ListViewMoveDirection none
-- @field [parent=#ListViewMoveDirection] int#int none preloaded module

--------------------------------------------------------
-- the ListViewMoveDirection up
-- @field [parent=#ListViewMoveDirection] int#int up preloaded module

--------------------------------------------------------
-- the ListViewMoveDirection down
-- @field [parent=#ListViewMoveDirection] int#int down preloaded module

--------------------------------------------------------
-- the ListViewMoveDirection left
-- @field [parent=#ListViewMoveDirection] int#int left preloaded module

--------------------------------------------------------
-- the ListViewMoveDirection right
-- @field [parent=#ListViewMoveDirection] int#int right preloaded module

return nil