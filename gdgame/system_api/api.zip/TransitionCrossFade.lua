
--------------------------------
-- @module TransitionCrossFade
-- @extend TransitionScene
-- @parent_module cc

--------------------------------
-- 
-- @function [parent=#TransitionCrossFade] create 
-- @param self
-- @param #float t
-- @param #cc.Scene scene
-- @return TransitionCrossFade#TransitionCrossFade ret (return value: cc.TransitionCrossFade)
        
--------------------------------
-- js NA<br>
-- lua NA
-- @function [parent=#TransitionCrossFade] draw 
-- @param self
-- @param #cc.Renderer renderer
-- @param #mat4_table transform
-- @param #unsigned int flags
        
return nil
