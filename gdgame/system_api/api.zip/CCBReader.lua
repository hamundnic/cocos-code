
--------------------------------
-- @module CCBReader
-- @extend Ref
-- @parent_module cc

--------------------------------
-- 
-- @function [parent=#CCBReader] addOwnerOutletName 
-- @param self
-- @param #string name
        
--------------------------------
-- 
-- @function [parent=#CCBReader] getOwnerCallbackNames 
-- @param self
-- @return array_table#array_table ret (return value: array_table)
        
--------------------------------
-- 
-- @function [parent=#CCBReader] addDocumentCallbackControlEvents 
-- @param self
-- @param #int eventType
        
--------------------------------
-- 
-- @function [parent=#CCBReader] setCCBRootPath 
-- @param self
-- @param #char ccbRootPath
        
--------------------------------
-- 
-- @function [parent=#CCBReader] addOwnerOutletNode 
-- @param self
-- @param #cc.Node node
        
--------------------------------
-- 
-- @function [parent=#CCBReader] getOwnerCallbackNodes 
-- @param self
-- @return array_table#array_table ret (return value: array_table)
        
--------------------------------
-- 
-- @function [parent=#CCBReader] readSoundKeyframesForSeq 
-- @param self
-- @param #cc.CCBSequence seq
-- @return bool#bool ret (return value: bool)
        
--------------------------------
-- 
-- @function [parent=#CCBReader] getCCBRootPath 
-- @param self
-- @return string#string ret (return value: string)
        
--------------------------------
-- 
-- @function [parent=#CCBReader] getOwnerCallbackControlEvents 
-- @param self
-- @return array_table#array_table ret (return value: array_table)
        
--------------------------------
-- 
-- @function [parent=#CCBReader] getOwnerOutletNodes 
-- @param self
-- @return array_table#array_table ret (return value: array_table)
        
--------------------------------
-- 
-- @function [parent=#CCBReader] readUTF8 
-- @param self
-- @return string#string ret (return value: string)
        
--------------------------------
-- 
-- @function [parent=#CCBReader] addOwnerCallbackControlEvents 
-- @param self
-- @param #int type
        
--------------------------------
-- @function [parent=#CCBReader] getOwnerOutletNames 
-- @param self
-- @return array_table#array_table ret (return value: array_table)
        
--------------------------------
-- rename;setAnimationManager=setActionManager
-- js setActionManager<br>
-- lua setActionManager
-- @function [parent=#CCBReader] setActionManager 
-- @param self
-- @param #cc.CCBAnimationManager pAnimationManager
        
--------------------------------
-- 
-- @function [parent=#CCBReader] readCallbackKeyframesForSeq 
-- @param self
-- @param #cc.CCBSequence seq
-- @return bool#bool ret (return value: bool)
        
--------------------------------
-- rename:getAnimationManager=getActionManager
-- @function [parent=#CCBReader] getActionManager 
-- @param self
-- @return array_table#array_table ret (return value: array_table)
        
--------------------------------
-- 
-- @function [parent=#CCBReader] getNodesWithAnimationManagers 
-- @param self
-- @return array_table#array_table ret (return value: array_table)
        
--------------------------------
-- js getActionManager<br>
-- lua getActionManager
-- @function [parent=#CCBReader] getAnimationManager 
-- @param self
-- @return CCBAnimationManager#CCBAnimationManager ret (return value: cc.CCBAnimationManager)
        
--------------------------------
-- 
-- @function [parent=#CCBReader] setResolutionScale 
-- @param self
-- @param #float scale
        
--------------------------------
-- @overload self, cc.CCBReader         
-- @overload self, cc.NodeLoaderLibrary, cc.CCBMemberVariableAssigner, cc.CCBSelectorResolver, cc.NodeLoaderListener         
-- @overload self         
-- @function [parent=#CCBReader] CCBReader
-- @param self
-- @param #cc.NodeLoaderLibrary pNodeLoaderLibrary
-- @param #cc.CCBMemberVariableAssigner pCCBMemberVariableAssigner
-- @param #cc.CCBSelectorResolver pCCBSelectorResolver
-- @param #cc.NodeLoaderListener pNodeLoaderListener




--------------------------------
-- @function [parent=#CCBReader] load 
-- @param self
-- @param #string filename
-- @param #cc.Ref ref
-- @param #size_table size
-- @return Node#Node ret (return value: cc.Node)



return nil
