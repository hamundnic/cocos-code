
--------------------------------
-- @module LoadingBarDirection
-- @parent_module ccui

--------------------------------------------------------
-- the LoadingBarDirection LEFT
-- @field [parent=#LoadingBarDirection] int#int LEFT preloaded module

--------------------------------------------------------
-- the LoadingBarDirection RIGHT
-- @field [parent=#LoadingBarDirection] int#int RIGHT preloaded module

return nil