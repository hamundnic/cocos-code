
--------------------------------
-- @module EaseSineIn
-- @extend ActionEase
-- @parent_module cc

--------------------------------
--  creates the action 
-- @function [parent=#EaseSineIn] create 
-- @param self
-- @param #cc.ActionInterval action
-- @return EaseSineIn#EaseSineIn ret (return value: cc.EaseSineIn)
        
--------------------------------
-- 
-- @function [parent=#EaseSineIn] clone 
-- @param self
-- @return EaseSineIn#EaseSineIn ret (return value: cc.EaseSineIn)
        
--------------------------------
-- 
-- @function [parent=#EaseSineIn] update 
-- @param self
-- @param #float time
        
--------------------------------
-- 
-- @function [parent=#EaseSineIn] reverse 
-- @param self
-- @return ActionEase#ActionEase ret (return value: cc.ActionEase)
        
return nil
