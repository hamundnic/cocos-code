
--------------------------------
-- @module EventCustom
-- @extend Event
-- @parent_module cc

--------------------------------
--  Gets event name 
-- @function [parent=#EventCustom] getEventName 
-- @param self
-- @return string#string ret (return value: string)
        
--------------------------------
--  Constructor 
-- @function [parent=#EventCustom] EventCustom 
-- @param self
-- @param #string eventName
        
return nil
