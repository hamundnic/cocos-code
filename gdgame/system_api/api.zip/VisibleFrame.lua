
--------------------------------
-- @module VisibleFrame
-- @extend Frame
-- @parent_module ccs

--------------------------------
-- 
-- @function [parent=#VisibleFrame] isVisible 
-- @param self
-- @return bool#bool ret (return value: bool)
        
--------------------------------
-- 
-- @function [parent=#VisibleFrame] setVisible 
-- @param self
-- @param #bool visible
        
--------------------------------
-- 
-- @function [parent=#VisibleFrame] create 
-- @param self
-- @return VisibleFrame#VisibleFrame ret (return value: ccs.VisibleFrame)
        
--------------------------------
-- 
-- @function [parent=#VisibleFrame] clone 
-- @param self
-- @return Frame#Frame ret (return value: ccs.Frame)
        
--------------------------------
-- 
-- @function [parent=#VisibleFrame] VisibleFrame 
-- @param self
        
return nil
