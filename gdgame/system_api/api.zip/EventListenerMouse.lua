
--------------------------------
-- @module EventListenerMouse
-- @extend EventListener
-- @parent_module cc

--------------------------------
-- / Overrides
-- @function [parent=#EventListenerMouse] clone 
-- @param self
-- @return EventListenerMouse#EventListenerMouse ret (return value: cc.EventListenerMouse)
        
--------------------------------
-- 
-- @function [parent=#EventListenerMouse] checkAvailable 
-- @param self
-- @return bool#bool ret (return value: bool)
  
	



--------------------------------
-- @function [parent=#EventListenerMouse] create 
-- @param self
-- @return EventListenerMouse#EventListenerMouse ret (return value: cc.EventListenerMouse)

--------------------------------
-- @function [parent=#EventListenerMouse] registerScriptHandler 
-- @param self
-- @param #function handler
-- @param #int type




return nil
