
--------------------------------
-- @module CallFunc
-- @extend ActionInstant
-- @parent_module cc

--------------------------------
--  executes the callback 
-- @function [parent=#CallFunc] execute 
-- @param self
        
--------------------------------
-- 
-- @function [parent=#CallFunc] getTargetCallback 
-- @param self
-- @return Ref#Ref ret (return value: cc.Ref)
        
--------------------------------
-- 
-- @function [parent=#CallFunc] setTargetCallback 
-- @param self
-- @param #cc.Ref sel
        
--------------------------------
-- 
-- @function [parent=#CallFunc] clone 
-- @param self
-- @return CallFunc#CallFunc ret (return value: cc.CallFunc)
        
--------------------------------
-- 
-- @function [parent=#CallFunc] update 
-- @param self
-- @param #float time
        
--------------------------------
-- 
-- @function [parent=#CallFunc] reverse 
-- @param self
-- @return CallFunc#CallFunc ret (return value: cc.CallFunc)
  
	




--------------------------------
-- @function [parent=#CallFunc] create 
-- @param self
-- @param #function handler
-- @param #table values
-- @return CallFunc#CallFunc ret (return value: cc.CallFunc)






return nil
