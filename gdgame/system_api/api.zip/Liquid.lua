
--------------------------------
-- @module Liquid
-- @extend Grid3DAction
-- @parent_module cc

--------------------------------
-- 
-- @function [parent=#Liquid] getAmplitudeRate 
-- @param self
-- @return float#float ret (return value: float)
        
--------------------------------
-- 
-- @function [parent=#Liquid] setAmplitude 
-- @param self
-- @param #float amplitude
        
--------------------------------
-- 
-- @function [parent=#Liquid] setAmplitudeRate 
-- @param self
-- @param #float amplitudeRate
        
--------------------------------
-- 
-- @function [parent=#Liquid] getAmplitude 
-- @param self
-- @return float#float ret (return value: float)
        
--------------------------------
--  creates the action with amplitude, a grid and duration 
-- @function [parent=#Liquid] create 
-- @param self
-- @param #float duration
-- @param #size_table gridSize
-- @param #unsigned int waves
-- @param #float amplitude
-- @return Liquid#Liquid ret (return value: cc.Liquid)
        
--------------------------------
-- 
-- @function [parent=#Liquid] clone 
-- @param self
-- @return Liquid#Liquid ret (return value: cc.Liquid)
        
--------------------------------
-- 
-- @function [parent=#Liquid] update 
-- @param self
-- @param #float time
        
return nil
