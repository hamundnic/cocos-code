
--------------------------------
-- @module EaseQuadraticActionOut
-- @extend ActionEase
-- @parent_module cc

--------------------------------
--  creates the action 
-- @function [parent=#EaseQuadraticActionOut] create 
-- @param self
-- @param #cc.ActionInterval action
-- @return EaseQuadraticActionOut#EaseQuadraticActionOut ret (return value: cc.EaseQuadraticActionOut)
        
--------------------------------
-- 
-- @function [parent=#EaseQuadraticActionOut] clone 
-- @param self
-- @return EaseQuadraticActionOut#EaseQuadraticActionOut ret (return value: cc.EaseQuadraticActionOut)
        
--------------------------------
-- 
-- @function [parent=#EaseQuadraticActionOut] update 
-- @param self
-- @param #float time
        
--------------------------------
-- 
-- @function [parent=#EaseQuadraticActionOut] reverse 
-- @param self
-- @return EaseQuadraticActionOut#EaseQuadraticActionOut ret (return value: cc.EaseQuadraticActionOut)
        
return nil
