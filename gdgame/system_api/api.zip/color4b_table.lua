
--------------------------------
-- @module color4b_table

--------------------------------------------------------
-- the color4b_table r 
-- @field [parent=#color4b_table] #uchar r preloaded module

--------------------------------------------------------
-- the color4b_table g 
-- @field [parent=#color4b_table] #uchar g preloaded module

--------------------------------------------------------
-- the color4b_table b 
-- @field [parent=#color4b_table] #uchar b preloaded module

--------------------------------------------------------
-- the color4b_table a 
-- @field [parent=#color4b_table] #uchar a preloaded module

return nil
