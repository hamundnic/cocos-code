
--------------------------------
-- @module PhysicsShapeBox
-- @extend PhysicsShapePolygon
-- @parent_module cc

--------------------------------
-- 
-- @function [parent=#PhysicsShapeBox] getSize 
-- @param self
-- @return size_table#size_table ret (return value: size_table)
        
--------------------------------
-- 
-- @function [parent=#PhysicsShapeBox] create 
-- @param self
-- @param #size_table size
-- @param #cc.PhysicsMaterial material
-- @param #vec2_table offset
-- @return PhysicsShapeBox#PhysicsShapeBox ret (return value: cc.PhysicsShapeBox)
        
--------------------------------
-- 
-- @function [parent=#PhysicsShapeBox] getOffset 
-- @param self
-- @return vec2_table#vec2_table ret (return value: vec2_table)

	



--------------------------------
-- @function [parent=#PhysicsShapeBox] getPoints 
-- @param self
-- @return table#table ret (return points_table)

--------------------------------
-- @function [parent=#PhysicsShapePolygon] getPoints 
-- @param self
-- @return table#table ret (return points_table)


--------------------------------
-- @function [parent=#PhysicsShapeEdgeBox] getPoints 
-- @param self
-- @return table#table ret (return points_table)

--------------------------------
-- @function [parent=#PhysicsShapeEdgePolygon] getPoints 
-- @param self
-- @return table#table ret (return points_table)

--------------------------------
-- @function [parent=#PhysicsShapeEdgeChain] getPoints 
-- @param self
-- @return table#table ret (return points_table)

--------------------------------
-- @function [parent=#EventListenerPhysicsContact] registerScriptHandler 
-- @param self
-- @param #int handler
-- @param #HandlerType type




return nil
