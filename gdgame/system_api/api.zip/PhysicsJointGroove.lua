
--------------------------------
-- @module PhysicsJointGroove
-- @extend PhysicsJoint
-- @parent_module cc

--------------------------------
-- 
-- @function [parent=#PhysicsJointGroove] setAnchr2 
-- @param self
-- @param #vec2_table anchr2
        
--------------------------------
-- 
-- @function [parent=#PhysicsJointGroove] setGrooveA 
-- @param self
-- @param #vec2_table grooveA
        
--------------------------------
-- 
-- @function [parent=#PhysicsJointGroove] setGrooveB 
-- @param self
-- @param #vec2_table grooveB
        
--------------------------------
-- 
-- @function [parent=#PhysicsJointGroove] getGrooveA 
-- @param self
-- @return vec2_table#vec2_table ret (return value: vec2_table)
        
--------------------------------
-- 
-- @function [parent=#PhysicsJointGroove] getGrooveB 
-- @param self
-- @return vec2_table#vec2_table ret (return value: vec2_table)
        
--------------------------------
-- 
-- @function [parent=#PhysicsJointGroove] getAnchr2 
-- @param self
-- @return vec2_table#vec2_table ret (return value: vec2_table)
        
--------------------------------
-- 
-- @function [parent=#PhysicsJointGroove] construct 
-- @param self
-- @param #cc.PhysicsBody a
-- @param #cc.PhysicsBody b
-- @param #vec2_table grooveA
-- @param #vec2_table grooveB
-- @param #vec2_table anchr2
-- @return PhysicsJointGroove#PhysicsJointGroove ret (return value: cc.PhysicsJointGroove)
        
return nil
