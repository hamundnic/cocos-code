
--------------------------------
-- @module EaseQuinticActionOut
-- @extend ActionEase
-- @parent_module cc

--------------------------------
--  creates the action 
-- @function [parent=#EaseQuinticActionOut] create 
-- @param self
-- @param #cc.ActionInterval action
-- @return EaseQuinticActionOut#EaseQuinticActionOut ret (return value: cc.EaseQuinticActionOut)
        
--------------------------------
-- 
-- @function [parent=#EaseQuinticActionOut] clone 
-- @param self
-- @return EaseQuinticActionOut#EaseQuinticActionOut ret (return value: cc.EaseQuinticActionOut)
        
--------------------------------
-- 
-- @function [parent=#EaseQuinticActionOut] update 
-- @param self
-- @param #float time
        
--------------------------------
-- 
-- @function [parent=#EaseQuinticActionOut] reverse 
-- @param self
-- @return EaseQuinticActionOut#EaseQuinticActionOut ret (return value: cc.EaseQuinticActionOut)
        
return nil
