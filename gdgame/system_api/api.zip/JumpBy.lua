
--------------------------------
-- @module JumpBy
-- @extend ActionInterval
-- @parent_module cc

--------------------------------
--  creates the action 
-- @function [parent=#JumpBy] create 
-- @param self
-- @param #float duration
-- @param #vec2_table position
-- @param #float height
-- @param #int jumps
-- @return JumpBy#JumpBy ret (return value: cc.JumpBy)
        
--------------------------------
-- 
-- @function [parent=#JumpBy] startWithTarget 
-- @param self
-- @param #cc.Node target
        
--------------------------------
-- 
-- @function [parent=#JumpBy] clone 
-- @param self
-- @return JumpBy#JumpBy ret (return value: cc.JumpBy)
        
--------------------------------
-- 
-- @function [parent=#JumpBy] reverse 
-- @param self
-- @return JumpBy#JumpBy ret (return value: cc.JumpBy)
        
--------------------------------
-- 
-- @function [parent=#JumpBy] update 
-- @param self
-- @param #float time
        
return nil
