
--------------------------------
-- @module TransitionSplitRows
-- @extend TransitionSplitCols
-- @parent_module cc

--------------------------------
-- 
-- @function [parent=#TransitionSplitRows] create 
-- @param self
-- @param #float t
-- @param #cc.Scene scene
-- @return TransitionSplitRows#TransitionSplitRows ret (return value: cc.TransitionSplitRows)
        
--------------------------------
-- 
-- @function [parent=#TransitionSplitRows] action 
-- @param self
-- @return ActionInterval#ActionInterval ret (return value: cc.ActionInterval)
        
return nil
