
--------------------------------
-- @module FlipY3D
-- @extend FlipX3D
-- @parent_module cc

--------------------------------
--  creates the action with duration 
-- @function [parent=#FlipY3D] create 
-- @param self
-- @param #float duration
-- @return FlipY3D#FlipY3D ret (return value: cc.FlipY3D)
        
--------------------------------
-- 
-- @function [parent=#FlipY3D] clone 
-- @param self
-- @return FlipY3D#FlipY3D ret (return value: cc.FlipY3D)
        
--------------------------------
-- 
-- @function [parent=#FlipY3D] update 
-- @param self
-- @param #float time
        
return nil
