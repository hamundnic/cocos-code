
--------------------------------
-- @module CheckBoxEventType
-- @@parent_module ccui

--------------------------------------------------------
-- the CheckBoxEventType selected
-- @field [parent=#CheckBoxEventType] int#int selected preloaded module

--------------------------------------------------------
-- the CheckBoxEventType unselected
-- @field [parent=#CheckBoxEventType] int#int unselected preloaded module

return nil