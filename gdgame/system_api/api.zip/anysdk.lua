--------------------------------
-- @module anysdk

--------------------------------------------------------
-- the anysdk PluginProtocol
-- @field [parent=#anysdk] PluginProtocol#PluginProtocol PluginProtocol preloaded module

--------------------------------------------------------
-- the anysdk PluginShare
-- @field [parent=#anysdk] PluginShare#PluginShare PluginShare preloaded module

--------------------------------------------------------
-- the anysdk PluginParam
-- @field [parent=#anysdk] PluginParam#PluginParam PluginParam preloaded module


--------------------------------------------------------
-- the anysdk PluginFactory
-- @field [parent=#anysdk] PluginFactory#PluginFactory PluginFactory preloaded module


--------------------------------------------------------
-- the anysdk PluginManager
-- @field [parent=#anysdk] PluginManager#PluginManager PluginManager preloaded module


--------------------------------------------------------
-- the anysdk ProtocolIAP
-- @field [parent=#anysdk] ProtocolIAP#ProtocolIAP ProtocolIAP preloaded module


--------------------------------------------------------
-- the anysdk ProtocolAnalytics
-- @field [parent=#anysdk] ProtocolAnalytics#ProtocolAnalytics ProtocolAnalytics preloaded module


--------------------------------------------------------
-- the anysdk ProtocolAds
-- @field [parent=#anysdk] ProtocolAds#ProtocolAds ProtocolAds preloaded module


--------------------------------------------------------
-- the anysdk ProtocolSocial
-- @field [parent=#anysdk] ProtocolSocial#ProtocolSocial ProtocolSocial preloaded module


--------------------------------------------------------
-- the anysdk ProtocolUser
-- @field [parent=#anysdk] ProtocolUser#ProtocolUser ProtocolUser preloaded module


--------------------------------------------------------
-- the anysdk ProtocolPush
-- @field [parent=#anysdk] ProtocolPush#ProtocolPush ProtocolPush preloaded module


--------------------------------------------------------
-- the anysdk AgentManager
-- @field [parent=#anysdk] AgentManager#AgentManager AgentManager preloaded module


return nil
