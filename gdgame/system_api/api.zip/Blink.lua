
--------------------------------
-- @module Blink
-- @extend ActionInterval
-- @parent_module cc

--------------------------------
--  creates the action 
-- @function [parent=#Blink] create 
-- @param self
-- @param #float duration
-- @param #int blinks
-- @return Blink#Blink ret (return value: cc.Blink)
        
--------------------------------
-- 
-- @function [parent=#Blink] startWithTarget 
-- @param self
-- @param #cc.Node target
        
--------------------------------
-- 
-- @function [parent=#Blink] clone 
-- @param self
-- @return Blink#Blink ret (return value: cc.Blink)
        
--------------------------------
-- 
-- @function [parent=#Blink] stop 
-- @param self
        
--------------------------------
-- 
-- @function [parent=#Blink] reverse 
-- @param self
-- @return Blink#Blink ret (return value: cc.Blink)
        
--------------------------------
-- 
-- @function [parent=#Blink] update 
-- @param self
-- @param #float time
        
return nil
