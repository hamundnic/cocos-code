
--------------------------------
-- @module PageTurn3D
-- @extend Grid3DAction
-- @parent_module cc

--------------------------------
--  create the action 
-- @function [parent=#PageTurn3D] create 
-- @param self
-- @param #float duration
-- @param #size_table gridSize
-- @return PageTurn3D#PageTurn3D ret (return value: cc.PageTurn3D)
        
--------------------------------
-- 
-- @function [parent=#PageTurn3D] clone 
-- @param self
-- @return PageTurn3D#PageTurn3D ret (return value: cc.PageTurn3D)
        
--------------------------------
-- 
-- @function [parent=#PageTurn3D] update 
-- @param self
-- @param #float time
        
return nil
