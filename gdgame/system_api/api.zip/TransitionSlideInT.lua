
--------------------------------
-- @module TransitionSlideInT
-- @extend TransitionSlideInL
-- @parent_module cc

--------------------------------
--  returns the action that will be performed by the incoming and outgoing scene 
-- @function [parent=#TransitionSlideInT] action 
-- @param self
-- @return ActionInterval#ActionInterval ret (return value: cc.ActionInterval)
        
--------------------------------
-- 
-- @function [parent=#TransitionSlideInT] create 
-- @param self
-- @param #float t
-- @param #cc.Scene scene
-- @return TransitionSlideInT#TransitionSlideInT ret (return value: cc.TransitionSlideInT)
        
return nil
