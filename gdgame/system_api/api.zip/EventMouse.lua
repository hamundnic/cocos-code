
--------------------------------
-- @module EventMouse
-- @extend Event
-- @parent_module cc

--------------------------------
-- 
-- @function [parent=#EventMouse] getMouseButton 
-- @param self
-- @return int#int ret (return value: int)
        
--------------------------------
--  Set mouse scroll data 
-- @function [parent=#EventMouse] setScrollData 
-- @param self
-- @param #float scrollX
-- @param #float scrollY
        
--------------------------------
-- 
-- @function [parent=#EventMouse] setMouseButton 
-- @param self
-- @param #int button
        
--------------------------------
-- 
-- @function [parent=#EventMouse] getScrollY 
-- @param self
-- @return float#float ret (return value: float)
        
--------------------------------
-- 
-- @function [parent=#EventMouse] getScrollX 
-- @param self
-- @return float#float ret (return value: float)
        
--------------------------------
-- 
-- @function [parent=#EventMouse] getCursorX 
-- @param self
-- @return float#float ret (return value: float)
        
--------------------------------
-- 
-- @function [parent=#EventMouse] getCursorY 
-- @param self
-- @return float#float ret (return value: float)
        
--------------------------------
-- 
-- @function [parent=#EventMouse] setCursorPosition 
-- @param self
-- @param #float x
-- @param #float y
        
--------------------------------
-- 
-- @function [parent=#EventMouse] EventMouse 
-- @param self
-- @param #int mouseEventCode
        
return nil
