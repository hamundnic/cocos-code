
--------------------------------
-- @module LuaJavaBridge

--------------------------------
-- only for android
-- @function [parent=#LuaJavaBridge] callStaticMethod 
-- @param #string className
-- @param #string methodName
-- @param #table args
-- @param #string methodSig
-- return bool,int
-- @return int#int ret (return value: int)

return nil
