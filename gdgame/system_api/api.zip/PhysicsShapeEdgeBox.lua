
--------------------------------
-- @module PhysicsShapeEdgeBox
-- @extend PhysicsShapeEdgePolygon
-- @parent_module cc

--------------------------------
-- 
-- @function [parent=#PhysicsShapeEdgeBox] create 
-- @param self
-- @param #size_table size
-- @param #cc.PhysicsMaterial material
-- @param #float border
-- @param #vec2_table offset
-- @return PhysicsShapeEdgeBox#PhysicsShapeEdgeBox ret (return value: cc.PhysicsShapeEdgeBox)
        
--------------------------------
-- 
-- @function [parent=#PhysicsShapeEdgeBox] getOffset 
-- @param self
-- @return vec2_table#vec2_table ret (return value: vec2_table)
        
return nil
