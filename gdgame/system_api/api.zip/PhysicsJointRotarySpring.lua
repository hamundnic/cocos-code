
--------------------------------
-- @module PhysicsJointRotarySpring
-- @extend PhysicsJoint
-- @parent_module cc

--------------------------------
-- 
-- @function [parent=#PhysicsJointRotarySpring] getDamping 
-- @param self
-- @return float#float ret (return value: float)
        
--------------------------------
-- 
-- @function [parent=#PhysicsJointRotarySpring] setRestAngle 
-- @param self
-- @param #float restAngle
        
--------------------------------
-- 
-- @function [parent=#PhysicsJointRotarySpring] getStiffness 
-- @param self
-- @return float#float ret (return value: float)
        
--------------------------------
-- 
-- @function [parent=#PhysicsJointRotarySpring] setStiffness 
-- @param self
-- @param #float stiffness
        
--------------------------------
-- 
-- @function [parent=#PhysicsJointRotarySpring] setDamping 
-- @param self
-- @param #float damping
        
--------------------------------
-- 
-- @function [parent=#PhysicsJointRotarySpring] getRestAngle 
-- @param self
-- @return float#float ret (return value: float)
        
--------------------------------
-- 
-- @function [parent=#PhysicsJointRotarySpring] construct 
-- @param self
-- @param #cc.PhysicsBody a
-- @param #cc.PhysicsBody b
-- @param #float stiffness
-- @param #float damping
-- @return PhysicsJointRotarySpring#PhysicsJointRotarySpring ret (return value: cc.PhysicsJointRotarySpring)
        
return nil
