
--------------------------------
-- @module ListViewEventType

--------------------------------------------------------
-- the ListViewEventType ONSELECTEDITEM_START
-- @field [parent=#ListViewEventType] int#int ONSELECTEDITEM_START preloaded module

--------------------------------------------------------
-- the ListViewEventType ONSELECTEDITEM_END
-- @field [parent=#ListViewEventType] int#int ONSELECTEDITEM_END preloaded module

return nil