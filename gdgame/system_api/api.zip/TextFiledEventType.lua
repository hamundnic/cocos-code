
--------------------------------
-- @module TextFiledEventType
-- @parent_module ccui

--------------------------------------------------------
-- the TextFiledEventType attach_with_ime
-- @field [parent=#TextFiledEventType] int#int attach_with_ime preloaded module

--------------------------------------------------------
-- the TextFiledEventType detach_with_ime
-- @field [parent=#TextFiledEventType] int#int detach_with_ime preloaded module

--------------------------------------------------------
-- the TextFiledEventType insert_text
-- @field [parent=#TextFiledEventType] int#int insert_text preloaded module

--------------------------------------------------------
-- the TextFiledEventType delete_backward
-- @field [parent=#TextFiledEventType] int#int delete_backward preloaded module

return nil