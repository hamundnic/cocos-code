
--------------------------------
-- @module TransitionSlideInL
-- @extend TransitionScene,TransitionEaseScene
-- @parent_module cc

--------------------------------
--  returns the action that will be performed by the incoming and outgoing scene 
-- @function [parent=#TransitionSlideInL] action 
-- @param self
-- @return ActionInterval#ActionInterval ret (return value: cc.ActionInterval)
        
--------------------------------
-- 
-- @function [parent=#TransitionSlideInL] easeActionWithAction 
-- @param self
-- @param #cc.ActionInterval action
-- @return ActionInterval#ActionInterval ret (return value: cc.ActionInterval)
        
--------------------------------
-- 
-- @function [parent=#TransitionSlideInL] create 
-- @param self
-- @param #float t
-- @param #cc.Scene scene
-- @return TransitionSlideInL#TransitionSlideInL ret (return value: cc.TransitionSlideInL)
        
return nil
