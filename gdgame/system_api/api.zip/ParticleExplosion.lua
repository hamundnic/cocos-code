
--------------------------------
-- @module ParticleExplosion
-- @extend ParticleSystemQuad
-- @parent_module cc

--------------------------------
-- 
-- @function [parent=#ParticleExplosion] create 
-- @param self
-- @return ParticleExplosion#ParticleExplosion ret (return value: cc.ParticleExplosion)
        
--------------------------------
-- 
-- @function [parent=#ParticleExplosion] createWithTotalParticles 
-- @param self
-- @param #int numberOfParticles
-- @return ParticleExplosion#ParticleExplosion ret (return value: cc.ParticleExplosion)
        
return nil
