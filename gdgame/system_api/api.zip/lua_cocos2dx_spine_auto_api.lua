--------------------------------
-- @module sp

--------------------------------------------------------
-- the sp Skeleton
-- @field [parent=#sp] Skeleton#Skeleton Skeleton preloaded module


--------------------------------------------------------
-- the sp SkeletonAnimation
-- @field [parent=#sp] SkeletonAnimation#SkeletonAnimation SkeletonAnimation preloaded module


return nil
