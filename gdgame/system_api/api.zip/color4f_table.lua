
--------------------------------
-- @module color4f_table

--------------------------------------------------------
-- the color4f_table r 
-- @field [parent=#color4f_table] #float r preloaded module

--------------------------------------------------------
-- the color4f_table g 
-- @field [parent=#color4f_table] #float g preloaded module

--------------------------------------------------------
-- the color4f_table b 
-- @field [parent=#color4f_table] #float b preloaded module

--------------------------------------------------------
-- the color4f_table a 
-- @field [parent=#color4f_table] #float a preloaded module

return nil
