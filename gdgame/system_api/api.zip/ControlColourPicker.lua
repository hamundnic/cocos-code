
--------------------------------
-- @module ControlColourPicker
-- @extend Control
-- @parent_module cc

--------------------------------
-- 
-- @function [parent=#ControlColourPicker] setEnabled 
-- @param self
-- @param #bool bEnabled
        
--------------------------------
-- 
-- @function [parent=#ControlColourPicker] getHuePicker 
-- @param self
-- @return ControlHuePicker#ControlHuePicker ret (return value: cc.ControlHuePicker)
        
--------------------------------
-- 
-- @function [parent=#ControlColourPicker] setColor 
-- @param self
-- @param #color3b_table colorValue
        
--------------------------------
-- 
-- @function [parent=#ControlColourPicker] hueSliderValueChanged 
-- @param self
-- @param #cc.Ref sender
-- @param #int controlEvent
        
--------------------------------
-- 
-- @function [parent=#ControlColourPicker] getcolourPicker 
-- @param self
-- @return ControlSaturationBrightnessPicker#ControlSaturationBrightnessPicker ret (return value: cc.ControlSaturationBrightnessPicker)
        
--------------------------------
-- 
-- @function [parent=#ControlColourPicker] setBackground 
-- @param self
-- @param #cc.Sprite var
        
--------------------------------
-- 
-- @function [parent=#ControlColourPicker] init 
-- @param self
-- @return bool#bool ret (return value: bool)
        
--------------------------------
-- 
-- @function [parent=#ControlColourPicker] setcolourPicker 
-- @param self
-- @param #cc.ControlSaturationBrightnessPicker var
        
--------------------------------
-- 
-- @function [parent=#ControlColourPicker] colourSliderValueChanged 
-- @param self
-- @param #cc.Ref sender
-- @param #int controlEvent
        
--------------------------------
-- 
-- @function [parent=#ControlColourPicker] setHuePicker 
-- @param self
-- @param #cc.ControlHuePicker var
        
--------------------------------
-- 
-- @function [parent=#ControlColourPicker] getBackground 
-- @param self
-- @return Sprite#Sprite ret (return value: cc.Sprite)
        
--------------------------------
-- 
-- @function [parent=#ControlColourPicker] create 
-- @param self
-- @return ControlColourPicker#ControlColourPicker ret (return value: cc.ControlColourPicker)
        
--------------------------------
-- js ctor
-- @function [parent=#ControlColourPicker] ControlColourPicker 
-- @param self
        
return nil
