--------------------------------
-- @module LabelEffect

--------------------------------------------------------
-- the LabelEffect NORMAL
-- @field [parent=#cc] #int NORMAL preloaded module

--------------------------------------------------------
-- the LabelEffect OUTLINE
-- @field [parent=#cc] #int OUTLINE preloaded module

--------------------------------------------------------
-- the LabelEffect SHADOW
-- @field [parent=#cc] #int SHADOW preloaded module

--------------------------------------------------------
-- the LabelEffect GLOW
-- @field [parent=#cc] #int GLOW preloaded module

return nil