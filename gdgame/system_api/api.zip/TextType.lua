
--------------------------------
-- @module TextType
-- @parent_module ccui

--------------------------------------------------------
-- the SizeType SYSTEM
-- @field [parent=#TextType] int#int SYSTEM preloaded module

--------------------------------------------------------
-- the SizeType percent
-- @field [parent=#TextType] int#int TTF preloaded module


        
return nil
