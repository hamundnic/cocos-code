
--------------------------------
-- @module ParticleFireworks
-- @extend ParticleSystemQuad
-- @parent_module cc

--------------------------------
-- 
-- @function [parent=#ParticleFireworks] create 
-- @param self
-- @return ParticleFireworks#ParticleFireworks ret (return value: cc.ParticleFireworks)
        
--------------------------------
-- 
-- @function [parent=#ParticleFireworks] createWithTotalParticles 
-- @param self
-- @param #int numberOfParticles
-- @return ParticleFireworks#ParticleFireworks ret (return value: cc.ParticleFireworks)
        
return nil
