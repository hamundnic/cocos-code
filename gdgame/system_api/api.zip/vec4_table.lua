
--------------------------------
-- @module vec4_table

--------------------------------------------------------
-- the vec4_table x 
-- @field [parent=#vec4_table] #float x preloaded module

--------------------------------------------------------
-- the vec4_table y 
-- @field [parent=#vec4_table] #float y preloaded module

--------------------------------------------------------
-- the vec4_table z 
-- @field [parent=#vec4_table] #float z preloaded module

--------------------------------------------------------
-- the vec4_table w 
-- @field [parent=#vec4_table] #float w preloaded module

return nil
