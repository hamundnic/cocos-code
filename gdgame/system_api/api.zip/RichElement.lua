
--------------------------------
-- @module RichElement
-- @extend Ref
-- @parent_module ccui

--------------------------------
-- 
-- @function [parent=#RichElement] init 
-- @param self
-- @param #int tag
-- @param #color3b_table color
-- @param #unsigned char opacity
-- @return bool#bool ret (return value: bool)
        
--------------------------------
-- 
-- @function [parent=#RichElement] RichElement 
-- @param self
        
return nil
