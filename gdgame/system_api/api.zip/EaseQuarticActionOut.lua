
--------------------------------
-- @module EaseQuarticActionOut
-- @extend ActionEase
-- @parent_module cc

--------------------------------
--  creates the action 
-- @function [parent=#EaseQuarticActionOut] create 
-- @param self
-- @param #cc.ActionInterval action
-- @return EaseQuarticActionOut#EaseQuarticActionOut ret (return value: cc.EaseQuarticActionOut)
        
--------------------------------
-- 
-- @function [parent=#EaseQuarticActionOut] clone 
-- @param self
-- @return EaseQuarticActionOut#EaseQuarticActionOut ret (return value: cc.EaseQuarticActionOut)
        
--------------------------------
-- 
-- @function [parent=#EaseQuarticActionOut] update 
-- @param self
-- @param #float time
        
--------------------------------
-- 
-- @function [parent=#EaseQuarticActionOut] reverse 
-- @param self
-- @return EaseQuarticActionOut#EaseQuarticActionOut ret (return value: cc.EaseQuarticActionOut)
        
return nil
