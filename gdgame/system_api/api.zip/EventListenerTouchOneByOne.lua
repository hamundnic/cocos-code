
--------------------------------
-- @module EventListenerTouchOneByOne
-- @extend EventListener
-- @parent_module cc

--------------------------------
-- 
-- @function [parent=#EventListenerTouchOneByOne] isSwallowTouches 
-- @param self
-- @return bool#bool ret (return value: bool)
        
--------------------------------
-- 
-- @function [parent=#EventListenerTouchOneByOne] setSwallowTouches 
-- @param self
-- @param #bool needSwallow
        
--------------------------------
-- / Overrides
-- @function [parent=#EventListenerTouchOneByOne] clone 
-- @param self
-- @return EventListenerTouchOneByOne#EventListenerTouchOneByOne ret (return value: cc.EventListenerTouchOneByOne)
        
--------------------------------
-- 
-- @function [parent=#EventListenerTouchOneByOne] checkAvailable 
-- @param self
-- @return bool#bool ret (return value: bool)
 
	



--------------------------------
-- @function [parent=#EventListenerTouchOneByOne] create 
-- @param self
-- @return EventListenerTouchOneByOne#EventListenerTouchOneByOne ret (return value: cc.EventListenerTouchOneByOne)

--------------------------------
-- @function [parent=#EventListenerTouchOneByOne] registerScriptHandler 
-- @param self
-- @param #function handler
-- @param #int type




return nil
