
--------------------------------
-- @module PluginFactory
-- @parent_module anysdk

--------------------------------
-- @Destory the instance of PluginFactory
-- @function [parent=#PluginFactory] purgeFactory 
-- @param self
        
--------------------------------
-- @Get singleton of PluginFactory
-- @function [parent=#PluginFactory] getInstance 
-- @param self
-- @return PluginFactory#PluginFactory ret (return value: anysdk.PluginFactory)
        
return nil
