
--------------------------------
-- @module CardinalSplineTo
-- @extend ActionInterval
-- @parent_module cc

--------------------------------
-- 
-- @function [parent=#CardinalSplineTo] getPoints 
-- @param self
-- @return point_table#point_table ret (return value: point_table)
        
--------------------------------
-- 
-- @function [parent=#CardinalSplineTo] updatePosition 
-- @param self
-- @param #vec2_table newPos
        
--------------------------------
--  initializes the action with a duration and an array of points 
-- @function [parent=#CardinalSplineTo] initWithDuration 
-- @param self
-- @param #float duration
-- @param #point_table points
-- @param #float tension
-- @return bool#bool ret (return value: bool)
        
--------------------------------
-- 
-- @function [parent=#CardinalSplineTo] startWithTarget 
-- @param self
-- @param #cc.Node target
        
--------------------------------
-- 
-- @function [parent=#CardinalSplineTo] clone 
-- @param self
-- @return CardinalSplineTo#CardinalSplineTo ret (return value: cc.CardinalSplineTo)
        
--------------------------------
-- 
-- @function [parent=#CardinalSplineTo] reverse 
-- @param self
-- @return CardinalSplineTo#CardinalSplineTo ret (return value: cc.CardinalSplineTo)
        
--------------------------------
-- 
-- @function [parent=#CardinalSplineTo] update 
-- @param self
-- @param #float time
        
--------------------------------
-- js NA<br>
-- lua NA
-- @function [parent=#CardinalSplineTo] CardinalSplineTo 
-- @param self
        
return nil
