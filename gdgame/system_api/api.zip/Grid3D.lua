
--------------------------------
-- @module Grid3D
-- @extend GridBase
-- @parent_module cc

--------------------------------
-- @overload self, size_table         
-- @overload self, size_table, cc.Texture2D, bool         
-- @function [parent=#Grid3D] create
-- @param self
-- @param #size_table gridSize
-- @param #cc.Texture2D texture
-- @param #bool flipped
-- @return Grid3D#Grid3D ret (retunr value: cc.Grid3D)

--------------------------------
-- 
-- @function [parent=#Grid3D] calculateVertexPoints 
-- @param self
        
--------------------------------
-- 
-- @function [parent=#Grid3D] blit 
-- @param self
        
--------------------------------
-- 
-- @function [parent=#Grid3D] reuse 
-- @param self
        
--------------------------------
-- js ctor
-- @function [parent=#Grid3D] Grid3D 
-- @param self
        
return nil
