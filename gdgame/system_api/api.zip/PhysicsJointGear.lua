
--------------------------------
-- @module PhysicsJointGear
-- @extend PhysicsJoint
-- @parent_module cc

--------------------------------
-- 
-- @function [parent=#PhysicsJointGear] setRatio 
-- @param self
-- @param #float ratchet
        
--------------------------------
-- 
-- @function [parent=#PhysicsJointGear] getPhase 
-- @param self
-- @return float#float ret (return value: float)
        
--------------------------------
-- 
-- @function [parent=#PhysicsJointGear] setPhase 
-- @param self
-- @param #float phase
        
--------------------------------
-- 
-- @function [parent=#PhysicsJointGear] getRatio 
-- @param self
-- @return float#float ret (return value: float)
        
--------------------------------
-- 
-- @function [parent=#PhysicsJointGear] construct 
-- @param self
-- @param #cc.PhysicsBody a
-- @param #cc.PhysicsBody b
-- @param #float phase
-- @param #float ratio
-- @return PhysicsJointGear#PhysicsJointGear ret (return value: cc.PhysicsJointGear)
        
return nil
