
--------------------------------
-- @module PhysicsShapePolygon
-- @extend PhysicsShape
-- @parent_module cc

--------------------------------
-- 
-- @function [parent=#PhysicsShapePolygon] getPointsCount 
-- @param self
-- @return int#int ret (return value: int)
        
--------------------------------
-- 
-- @function [parent=#PhysicsShapePolygon] getPoint 
-- @param self
-- @param #int i
-- @return vec2_table#vec2_table ret (return value: vec2_table)
        
--------------------------------
-- 
-- @function [parent=#PhysicsShapePolygon] calculateDefaultMoment 
-- @param self
-- @return float#float ret (return value: float)
        
--------------------------------
-- 
-- @function [parent=#PhysicsShapePolygon] getCenter 
-- @param self
-- @return vec2_table#vec2_table ret (return value: vec2_table)
        
return nil
