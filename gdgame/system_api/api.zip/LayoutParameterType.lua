

--------------------------------
-- @module LayoutParameterType
-- @parent_module ccui

--------------------------------------------------------
-- the LayoutParameterType none
-- @field [parent=#LayoutParameterType] int#int none preloaded module

--------------------------------------------------------
-- the LayoutParameterType linear
-- @field [parent=#LayoutParameterType] int#int linear preloaded module

--------------------------------------------------------
-- the LayoutParameterType relative
-- @field [parent=#LayoutParameterType] int#int relative preloaded module

return nil