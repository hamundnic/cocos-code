
--------------------------------
-- @module EaseCircleActionOut
-- @extend ActionEase
-- @parent_module cc

--------------------------------
--  creates the action 
-- @function [parent=#EaseCircleActionOut] create 
-- @param self
-- @param #cc.ActionInterval action
-- @return EaseCircleActionOut#EaseCircleActionOut ret (return value: cc.EaseCircleActionOut)
        
--------------------------------
-- 
-- @function [parent=#EaseCircleActionOut] clone 
-- @param self
-- @return EaseCircleActionOut#EaseCircleActionOut ret (return value: cc.EaseCircleActionOut)
        
--------------------------------
-- 
-- @function [parent=#EaseCircleActionOut] update 
-- @param self
-- @param #float time
        
--------------------------------
-- 
-- @function [parent=#EaseCircleActionOut] reverse 
-- @param self
-- @return EaseCircleActionOut#EaseCircleActionOut ret (return value: cc.EaseCircleActionOut)
        
return nil
