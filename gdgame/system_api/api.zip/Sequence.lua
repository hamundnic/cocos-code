
--------------------------------
-- @module Sequence
-- @extend ActionInterval
-- @parent_module cc

--------------------------------
-- 
-- @function [parent=#Sequence] startWithTarget 
-- @param self
-- @param #cc.Node target
        
--------------------------------
-- 
-- @function [parent=#Sequence] clone 
-- @param self
-- @return Sequence#Sequence ret (return value: cc.Sequence)
        
--------------------------------
-- 
-- @function [parent=#Sequence] stop 
-- @param self
        
--------------------------------
-- 
-- @function [parent=#Sequence] reverse 
-- @param self
-- @return Sequence#Sequence ret (return value: cc.Sequence)
        
--------------------------------
-- 
-- @function [parent=#Sequence] update 
-- @param self
-- @param #float t
   
	



--------------------------------
-- @overload self, table
-- @overload self, cc.FiniteTimeAction, cc.FiniteTimeAction
-- @function [parent=#Sequence] create 
-- @param self
-- @param #cc.FiniteTimeAction action1
-- @param #cc.FiniteTimeAction action2 ...
-- @return Sequence#Sequence ret (return value: cc.Sequence)





return nil
