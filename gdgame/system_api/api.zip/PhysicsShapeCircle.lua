
--------------------------------
-- @module PhysicsShapeCircle
-- @extend PhysicsShape
-- @parent_module cc

--------------------------------
-- 
-- @function [parent=#PhysicsShapeCircle] getRadius 
-- @param self
-- @return float#float ret (return value: float)
        
--------------------------------
-- 
-- @function [parent=#PhysicsShapeCircle] create 
-- @param self
-- @param #float radius
-- @param #cc.PhysicsMaterial material
-- @param #vec2_table offset
-- @return PhysicsShapeCircle#PhysicsShapeCircle ret (return value: cc.PhysicsShapeCircle)
        
--------------------------------
-- 
-- @function [parent=#PhysicsShapeCircle] calculateArea 
-- @param self
-- @param #float radius
-- @return float#float ret (return value: float)
        
--------------------------------
-- 
-- @function [parent=#PhysicsShapeCircle] calculateMoment 
-- @param self
-- @param #float mass
-- @param #float radius
-- @param #vec2_table offset
-- @return float#float ret (return value: float)
        
--------------------------------
-- 
-- @function [parent=#PhysicsShapeCircle] getOffset 
-- @param self
-- @return vec2_table#vec2_table ret (return value: vec2_table)
        
--------------------------------
-- 
-- @function [parent=#PhysicsShapeCircle] calculateDefaultMoment 
-- @param self
-- @return float#float ret (return value: float)
        
return nil
