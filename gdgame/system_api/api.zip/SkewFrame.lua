
--------------------------------
-- @module SkewFrame
-- @extend Frame
-- @parent_module ccs

--------------------------------
-- 
-- @function [parent=#SkewFrame] getSkewY 
-- @param self
-- @return float#float ret (return value: float)
        
--------------------------------
-- 
-- @function [parent=#SkewFrame] setSkewX 
-- @param self
-- @param #float skewx
        
--------------------------------
-- 
-- @function [parent=#SkewFrame] setSkewY 
-- @param self
-- @param #float skewy
        
--------------------------------
-- 
-- @function [parent=#SkewFrame] getSkewX 
-- @param self
-- @return float#float ret (return value: float)
        
--------------------------------
-- 
-- @function [parent=#SkewFrame] create 
-- @param self
-- @return SkewFrame#SkewFrame ret (return value: ccs.SkewFrame)
        
--------------------------------
-- 
-- @function [parent=#SkewFrame] apply 
-- @param self
-- @param #float percent
        
--------------------------------
-- 
-- @function [parent=#SkewFrame] clone 
-- @param self
-- @return Frame#Frame ret (return value: ccs.Frame)
        
--------------------------------
-- 
-- @function [parent=#SkewFrame] SkewFrame 
-- @param self
        
return nil
