
--------------------------------
-- @module ActionFadeFrame
-- @extend ActionFrame
-- @parent_module ccs

--------------------------------
-- Gets the fade action opacity.<br>
-- return the fade action opacity.
-- @function [parent=#ActionFadeFrame] getOpacity 
-- @param self
-- @return int#int ret (return value: int)
        
--------------------------------
-- Gets the ActionInterval of ActionFrame.<br>
-- parame duration   the duration time of ActionFrame<br>
-- return ActionInterval
-- @function [parent=#ActionFadeFrame] getAction 
-- @param self
-- @param #float duration
-- @return ActionInterval#ActionInterval ret (return value: cc.ActionInterval)
        
--------------------------------
-- Changes the fade action opacity.<br>
-- param opacity the fade action opacity
-- @function [parent=#ActionFadeFrame] setOpacity 
-- @param self
-- @param #int opacity
        
--------------------------------
-- Default constructor
-- @function [parent=#ActionFadeFrame] ActionFadeFrame 
-- @param self
        
return nil
