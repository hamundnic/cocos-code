
--------------------------------
-- @module AudioEngine

--------------------------------
-- @function [parent=#AudioEngine] stopAllEffects 
        
--------------------------------
-- @function [parent=#AudioEngine] getMusicVolume 
-- @return float#float ret (return value: float)
        
--------------------------------
-- @function [parent=#AudioEngine] isMusicPlaying 
-- @return bool#bool ret (return value: bool)

--------------------------------
-- @function [parent=#AudioEngine] getEffectsVolume 
-- @return float#float ret (return value: float)

--------------------------------
-- @function [parent=#AudioEngine] setMusicVolume 
-- @param #float float

--------------------------------
-- @function [parent=#AudioEngine] stopEffect 
-- @param #int int

--------------------------------
-- @function [parent=#AudioEngine] stopMusic 
-- @param #bool bool

--------------------------------
-- @function [parent=#AudioEngine] playMusic 
-- @param #char char
-- @param #bool bool

--------------------------------
-- @function [parent=#AudioEngine] pauseAllEffects

--------------------------------
-- @function [parent=#AudioEngine] preloadMusic 
-- @param #char char

--------------------------------
-- @function [parent=#AudioEngine] resumeMusic 

--------------------------------
-- @function [parent=#AudioEngine] playEffect
-- @param #string string
-- @param #bool bool
-- @return int#int ret (return value: int)

--------------------------------
-- @function [parent=#AudioEngine] rewindMusic 

--------------------------------
-- @function [parent=#AudioEngine] willPlayMusic 
-- @return bool#bool ret (return value: bool)

--------------------------------
-- @function [parent=#AudioEngine] unloadEffect 
-- @param #char char

--------------------------------
-- @function [parent=#AudioEngine] preloadEffect 
-- @param #char char

--------------------------------
-- @function [parent=#AudioEngine] willPlayMusic 
-- @return bool#bool ret (return value: bool)

--------------------------------
-- @function [parent=#AudioEngine] setEffectsVolume 
-- @param #float float

--------------------------------
-- @function [parent=#AudioEngine] pauseEffect 
-- @param #unsigned int int

--------------------------------
-- @function [parent=#AudioEngine] resumeAllEffects 
-- @param #float float

--------------------------------
-- @function [parent=#AudioEngine] pauseMusic 

--------------------------------
-- @function [parent=#AudioEngine] resumeEffect 

--------------------------------
-- @function [parent=#AudioEngine] pauseMusic 

--------------------------------
-- @function [parent=#AudioEngine] resumeEffect
-- @param #unsigned int int

return nil
