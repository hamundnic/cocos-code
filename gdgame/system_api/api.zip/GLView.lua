
--------------------------------
-- @module GLView
-- @extend GLViewProtocol,Ref
-- @parent_module cc

--------------------------------
-- 
-- @function [parent=#GLView] createWithRect 
-- @param self
-- @param #string viewName
-- @param #rect_table rect
-- @param #float frameZoomFactor
-- @return GLView#GLView ret (return value: cc.GLView)
        
--------------------------------
-- 
-- @function [parent=#GLView] create 
-- @param self
-- @param #string viewname
-- @return GLView#GLView ret (return value: cc.GLView)
        
--------------------------------
-- 
-- @function [parent=#GLView] createWithFullScreen 
-- @param self
-- @param #string viewName
-- @return GLView#GLView ret (return value: cc.GLView)
        
--------------------------------
-- 
-- @function [parent=#GLView] setIMEKeyboardState 
-- @param self
-- @param #bool bOpen
        
--------------------------------
-- 
-- @function [parent=#GLView] isOpenGLReady 
-- @param self
-- @return bool#bool ret (return value: bool)
        
return nil
