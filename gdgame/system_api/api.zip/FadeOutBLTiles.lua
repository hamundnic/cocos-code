
--------------------------------
-- @module FadeOutBLTiles
-- @extend FadeOutTRTiles
-- @parent_module cc

--------------------------------
--  creates the action with the grid size and the duration 
-- @function [parent=#FadeOutBLTiles] create 
-- @param self
-- @param #float duration
-- @param #size_table gridSize
-- @return FadeOutBLTiles#FadeOutBLTiles ret (return value: cc.FadeOutBLTiles)
        
--------------------------------
-- 
-- @function [parent=#FadeOutBLTiles] clone 
-- @param self
-- @return FadeOutBLTiles#FadeOutBLTiles ret (return value: cc.FadeOutBLTiles)
        
--------------------------------
-- 
-- @function [parent=#FadeOutBLTiles] testFunc 
-- @param self
-- @param #size_table pos
-- @param #float time
-- @return float#float ret (return value: float)
        
return nil
