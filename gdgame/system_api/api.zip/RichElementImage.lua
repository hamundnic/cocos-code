
--------------------------------
-- @module RichElementImage
-- @extend RichElement
-- @parent_module ccui

--------------------------------
-- 
-- @function [parent=#RichElementImage] init 
-- @param self
-- @param #int tag
-- @param #color3b_table color
-- @param #unsigned char opacity
-- @param #string filePath
-- @return bool#bool ret (return value: bool)
        
--------------------------------
-- 
-- @function [parent=#RichElementImage] create 
-- @param self
-- @param #int tag
-- @param #color3b_table color
-- @param #unsigned char opacity
-- @param #string filePath
-- @return RichElementImage#RichElementImage ret (return value: ccui.RichElementImage)
        
--------------------------------
-- 
-- @function [parent=#RichElementImage] RichElementImage 
-- @param self
        
return nil
