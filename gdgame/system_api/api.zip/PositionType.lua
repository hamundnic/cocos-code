
--------------------------------
-- @module PositionType
-- @parent_module ccui

--------------------------------------------------------
-- the PositionType began
-- @field [parent=#PositionType] int#int absolute preloaded module

--------------------------------------------------------
-- the PositionType percent
-- @field [parent=#PositionType] int#int percent preloaded module

return nil