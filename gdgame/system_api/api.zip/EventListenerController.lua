
--------------------------------
-- @module EventListenerController
-- @extend EventListener
-- @parent_module cc

--------------------------------
-- 
-- @function [parent=#EventListenerController] create 
-- @param self
-- @return EventListenerController#EventListenerController ret (return value: cc.EventListenerController)
        
--------------------------------
-- 
-- @function [parent=#EventListenerController] clone 
-- @param self
-- @return EventListenerController#EventListenerController ret (return value: cc.EventListenerController)
        
--------------------------------
-- / Overrides
-- @function [parent=#EventListenerController] checkAvailable 
-- @param self
-- @return bool#bool ret (return value: bool)
   
--------------------------------
-- @function [parent=#EventListenerController] clone 
-- @param self
-- @return EventListenerController#EventListenerController ret (return value: cc.EventListenerController)

--------------------------------
-- @function [parent=#EventListenerController] registerScriptHandler 
-- @param self
-- @param #function handler
-- @param #int type   
        
return nil
