
--------------------------------
-- @module FlipX3D
-- @extend Grid3DAction
-- @parent_module cc

--------------------------------
--  creates the action with duration 
-- @function [parent=#FlipX3D] create 
-- @param self
-- @param #float duration
-- @return FlipX3D#FlipX3D ret (return value: cc.FlipX3D)
        
--------------------------------
-- 
-- @function [parent=#FlipX3D] clone 
-- @param self
-- @return FlipX3D#FlipX3D ret (return value: cc.FlipX3D)
        
--------------------------------
-- 
-- @function [parent=#FlipX3D] update 
-- @param self
-- @param #float time
        
return nil
