
--------------------------------
-- @module EventListenerPhysicsContactWithShapes
-- @extend EventListenerPhysicsContact
-- @parent_module cc

--------------------------------
-- 
-- @function [parent=#EventListenerPhysicsContactWithShapes] hitTest 
-- @param self
-- @param #cc.PhysicsShape shapeA
-- @param #cc.PhysicsShape shapeB
-- @return bool#bool ret (return value: bool)
        
--------------------------------
-- 
-- @function [parent=#EventListenerPhysicsContactWithShapes] create 
-- @param self
-- @param #cc.PhysicsShape shapeA
-- @param #cc.PhysicsShape shapeB
-- @return EventListenerPhysicsContactWithShapes#EventListenerPhysicsContactWithShapes ret (return value: cc.EventListenerPhysicsContactWithShapes)
        
--------------------------------
-- 
-- @function [parent=#EventListenerPhysicsContactWithShapes] clone 
-- @param self
-- @return EventListenerPhysicsContactWithShapes#EventListenerPhysicsContactWithShapes ret (return value: cc.EventListenerPhysicsContactWithShapes)
        
return nil
