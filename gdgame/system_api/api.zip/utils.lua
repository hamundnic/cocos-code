
--------------------------------
-- @module utils
-- @parent_module cc

--------------------------------
-- @function [parent=#utils] captureScreen
-- @param self
-- @param #function handler
-- @param #string   filename

--------------------------------
-- @function [parent=#utils] findChildren
-- @param self
-- @param #cc.Node  node
-- @param #string name
-- @return table#table ret (return value: table)

return nil
