
--------------------------------
-- @module CardinalSplineBy
-- @extend CardinalSplineTo
-- @parent_module cc

--------------------------------
-- 
-- @function [parent=#CardinalSplineBy] startWithTarget 
-- @param self
-- @param #cc.Node target
        
--------------------------------
-- 
-- @function [parent=#CardinalSplineBy] clone 
-- @param self
-- @return CardinalSplineBy#CardinalSplineBy ret (return value: cc.CardinalSplineBy)
        
--------------------------------
-- 
-- @function [parent=#CardinalSplineBy] updatePosition 
-- @param self
-- @param #vec2_table newPos
        
--------------------------------
-- 
-- @function [parent=#CardinalSplineBy] reverse 
-- @param self
-- @return CardinalSplineBy#CardinalSplineBy ret (return value: cc.CardinalSplineBy)
        
--------------------------------
-- 
-- @function [parent=#CardinalSplineBy] CardinalSplineBy 
-- @param self
   
	




--------------------------------
-- @function [parent=#CardinalSplineBy] create 
-- @param self
-- @param #double dur
-- @param #point_table points
-- @param #double ten
-- @return CardinalSplineBy#CardinalSplineBy ret (return value: cc.CardinalSplineBy)






return nil
