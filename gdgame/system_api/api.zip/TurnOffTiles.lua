
--------------------------------
-- @module TurnOffTiles
-- @extend TiledGrid3DAction
-- @parent_module cc

--------------------------------
-- 
-- @function [parent=#TurnOffTiles] turnOnTile 
-- @param self
-- @param #vec2_table pos
        
--------------------------------
-- 
-- @function [parent=#TurnOffTiles] turnOffTile 
-- @param self
-- @param #vec2_table pos
        
--------------------------------
-- @overload self, float, size_table, unsigned int         
-- @overload self, float, size_table         
-- @function [parent=#TurnOffTiles] create
-- @param self
-- @param #float duration
-- @param #size_table gridSize
-- @param #unsigned int seed
-- @return TurnOffTiles#TurnOffTiles ret (retunr value: cc.TurnOffTiles)

--------------------------------
-- 
-- @function [parent=#TurnOffTiles] startWithTarget 
-- @param self
-- @param #cc.Node target
        
--------------------------------
-- 
-- @function [parent=#TurnOffTiles] clone 
-- @param self
-- @return TurnOffTiles#TurnOffTiles ret (return value: cc.TurnOffTiles)
        
--------------------------------
-- 
-- @function [parent=#TurnOffTiles] update 
-- @param self
-- @param #float time
        
return nil
