
--------------------------------
-- @module EventListenerFocus
-- @extend EventListener
-- @parent_module cc

--------------------------------
-- / Overrides
-- @function [parent=#EventListenerFocus] clone 
-- @param self
-- @return EventListenerFocus#EventListenerFocus ret (return value: cc.EventListenerFocus)
        
--------------------------------
-- 
-- @function [parent=#EventListenerFocus] checkAvailable 
-- @param self
-- @return bool#bool ret (return value: bool)

	



--------------------------------
-- @function [parent=#EventListenerFocus] create
-- @param self
-- @return EventListenerFocus#EventListenerFocus ret (return value: cc.EventListenerFocus)

--------------------------------
-- @function [parent=#EventListenerFocus] clone
-- @param self
-- @return EventListenerFocus#EventListenerFocus ret (return value: cc.EventListenerFocus)

--------------------------------
-- @function [parent=#EventListenerFocus] registerScriptHandler
-- @param self
-- @param #function handler





return nil
