
--------------------------------
-- @module ComController
-- @extend Component,InputDelegate
-- @parent_module ccs

--------------------------------
-- 
-- @function [parent=#ComController] create 
-- @param self
-- @return ComController#ComController ret (return value: ccs.ComController)
        
--------------------------------
-- 
-- @function [parent=#ComController] createInstance 
-- @param self
-- @return Ref#Ref ret (return value: cc.Ref)
        
--------------------------------
-- 
-- @function [parent=#ComController] setEnabled 
-- @param self
-- @param #bool b
        
--------------------------------
-- 
-- @function [parent=#ComController] isEnabled 
-- @param self
-- @return bool#bool ret (return value: bool)
        
--------------------------------
-- 
-- @function [parent=#ComController] update 
-- @param self
-- @param #float delta
        
--------------------------------
-- 
-- @function [parent=#ComController] init 
-- @param self
-- @return bool#bool ret (return value: bool)
        
--------------------------------
-- js ctor
-- @function [parent=#ComController] ComController 
-- @param self
        
return nil
