
--------------------------------
-- @module ScaleTo
-- @extend ActionInterval
-- @parent_module cc

--------------------------------
-- @overload self, float, float, float         
-- @overload self, float, float         
-- @overload self, float, float, float, float         
-- @function [parent=#ScaleTo] create
-- @param self
-- @param #float duration
-- @param #float sx
-- @param #float sy
-- @param #float sz
-- @return ScaleTo#ScaleTo ret (retunr value: cc.ScaleTo)

--------------------------------
-- 
-- @function [parent=#ScaleTo] startWithTarget 
-- @param self
-- @param #cc.Node target
        
--------------------------------
-- 
-- @function [parent=#ScaleTo] clone 
-- @param self
-- @return ScaleTo#ScaleTo ret (return value: cc.ScaleTo)
        
--------------------------------
-- 
-- @function [parent=#ScaleTo] reverse 
-- @param self
-- @return ScaleTo#ScaleTo ret (return value: cc.ScaleTo)
        
--------------------------------
-- 
-- @function [parent=#ScaleTo] update 
-- @param self
-- @param #float time
        
return nil
