
--------------------------------
-- @module SkewTo
-- @extend ActionInterval
-- @parent_module cc

--------------------------------
--  creates the action 
-- @function [parent=#SkewTo] create 
-- @param self
-- @param #float t
-- @param #float sx
-- @param #float sy
-- @return SkewTo#SkewTo ret (return value: cc.SkewTo)
        
--------------------------------
-- 
-- @function [parent=#SkewTo] startWithTarget 
-- @param self
-- @param #cc.Node target
        
--------------------------------
-- 
-- @function [parent=#SkewTo] clone 
-- @param self
-- @return SkewTo#SkewTo ret (return value: cc.SkewTo)
        
--------------------------------
-- 
-- @function [parent=#SkewTo] reverse 
-- @param self
-- @return SkewTo#SkewTo ret (return value: cc.SkewTo)
        
--------------------------------
-- 
-- @function [parent=#SkewTo] update 
-- @param self
-- @param #float time
        
return nil
