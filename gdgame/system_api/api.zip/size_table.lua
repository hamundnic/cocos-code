
--------------------------------
-- @module size_table

--------------------------------------------------------
-- the size_table width 
-- @field [parent=#size_table] #float width preloaded module

--------------------------------------------------------
-- the size_table height 
-- @field [parent=#size_table] #float height preloaded module

return nil
