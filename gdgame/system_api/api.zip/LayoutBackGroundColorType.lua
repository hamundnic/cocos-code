
--------------------------------
-- @module LayoutBackGroundColorType
-- @parent_module ccui

--------------------------------------------------------
-- the LayoutBackGroundColorType none
-- @field [parent=#LayoutBackGroundColorType] int#int none preloaded module

--------------------------------------------------------
-- the LayoutBackGroundColorType solid
-- @field [parent=#LayoutBackGroundColorType] int#int solid preloaded module

--------------------------------------------------------
-- the LayoutBackGroundColorType gradient
-- @field [parent=#LayoutBackGroundColorType] int#int gradient preloaded module

return nil