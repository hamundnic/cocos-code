
--------------------------------
-- @module PhysicsJointPin
-- @extend PhysicsJoint
-- @parent_module cc

--------------------------------
-- 
-- @function [parent=#PhysicsJointPin] construct 
-- @param self
-- @param #cc.PhysicsBody a
-- @param #cc.PhysicsBody b
-- @param #vec2_table anchr
-- @return PhysicsJointPin#PhysicsJointPin ret (return value: cc.PhysicsJointPin)
        
return nil
