
--------------------------------
-- @module GridAction
-- @extend ActionInterval
-- @parent_module cc

--------------------------------
--  returns the grid 
-- @function [parent=#GridAction] getGrid 
-- @param self
-- @return GridBase#GridBase ret (return value: cc.GridBase)
        
--------------------------------
-- 
-- @function [parent=#GridAction] startWithTarget 
-- @param self
-- @param #cc.Node target
        
--------------------------------
-- 
-- @function [parent=#GridAction] clone 
-- @param self
-- @return GridAction#GridAction ret (return value: cc.GridAction)
        
--------------------------------
-- @function [parent=#GridAction] reverse 
-- @param self
-- @return GridAction#GridAction ret (return value: cc.GridAction)
   
	



--------------------------------
-- @function [parent=#GridAction] reverse 
-- @param self
-- @param #function handler
-- @return GridAction#GridAction ret (return value: cc.GridAction)





return nil
