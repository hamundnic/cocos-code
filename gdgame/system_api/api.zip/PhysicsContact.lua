
--------------------------------
-- @module PhysicsContact
-- @extend EventCustom
-- @parent_module cc

--------------------------------
--  get contact data 
-- @function [parent=#PhysicsContact] getContactData 
-- @param self
-- @return PhysicsContactData#PhysicsContactData ret (return value: cc.PhysicsContactData)
        
--------------------------------
--  get the event code 
-- @function [parent=#PhysicsContact] getEventCode 
-- @param self
-- @return int#int ret (return value: int)
        
--------------------------------
--  get previous contact data 
-- @function [parent=#PhysicsContact] getPreContactData 
-- @param self
-- @return PhysicsContactData#PhysicsContactData ret (return value: cc.PhysicsContactData)
        
--------------------------------
--  get contact shape A. 
-- @function [parent=#PhysicsContact] getShapeA 
-- @param self
-- @return PhysicsShape#PhysicsShape ret (return value: cc.PhysicsShape)
        
--------------------------------
--  get contact shape B. 
-- @function [parent=#PhysicsContact] getShapeB 
-- @param self
-- @return PhysicsShape#PhysicsShape ret (return value: cc.PhysicsShape)
        
return nil
