
--------------------------------
-- @module ShaderCache
-- @extend Ref

--------------------------------
-- @function [parent=#ShaderCache] reloadDefaultShaders 
-- @param self
        
--------------------------------
-- @function [parent=#ShaderCache] addProgram 
-- @param self
-- @param #cc.GLProgram glprogram
-- @param #string str
        
--------------------------------
-- @function [parent=#ShaderCache] getProgram 
-- @param self
-- @param #string str
-- @return GLProgram#GLProgram ret (return value: cc.GLProgram)
        
--------------------------------
-- @function [parent=#ShaderCache] loadDefaultShaders 
-- @param self
        
--------------------------------
-- @function [parent=#ShaderCache] destroyInstance 
-- @param self
        
--------------------------------
-- @function [parent=#ShaderCache] getInstance 
-- @param self
-- @return ShaderCache#ShaderCache ret (return value: cc.ShaderCache)
        
--------------------------------
-- @function [parent=#ShaderCache] ShaderCache 
-- @param self
        
return nil
