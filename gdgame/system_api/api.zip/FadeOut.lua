
--------------------------------
-- @module FadeOut
-- @extend FadeTo
-- @parent_module cc

--------------------------------
-- 
-- @function [parent=#FadeOut] setReverseAction 
-- @param self
-- @param #cc.FadeTo ac
        
--------------------------------
--  creates the action 
-- @function [parent=#FadeOut] create 
-- @param self
-- @param #float d
-- @return FadeOut#FadeOut ret (return value: cc.FadeOut)
        
--------------------------------
-- 
-- @function [parent=#FadeOut] startWithTarget 
-- @param self
-- @param #cc.Node target
        
--------------------------------
-- 
-- @function [parent=#FadeOut] clone 
-- @param self
-- @return FadeOut#FadeOut ret (return value: cc.FadeOut)
        
--------------------------------
-- 
-- @function [parent=#FadeOut] reverse 
-- @param self
-- @return FadeTo#FadeTo ret (return value: cc.FadeTo)
        
return nil
