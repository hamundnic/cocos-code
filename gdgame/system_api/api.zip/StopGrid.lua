
--------------------------------
-- @module StopGrid
-- @extend ActionInstant
-- @parent_module cc

--------------------------------
--  Allocates and initializes the action 
-- @function [parent=#StopGrid] create 
-- @param self
-- @return StopGrid#StopGrid ret (return value: cc.StopGrid)
        
--------------------------------
-- 
-- @function [parent=#StopGrid] startWithTarget 
-- @param self
-- @param #cc.Node target
        
--------------------------------
-- 
-- @function [parent=#StopGrid] clone 
-- @param self
-- @return StopGrid#StopGrid ret (return value: cc.StopGrid)
        
--------------------------------
-- 
-- @function [parent=#StopGrid] reverse 
-- @param self
-- @return StopGrid#StopGrid ret (return value: cc.StopGrid)
        
return nil
