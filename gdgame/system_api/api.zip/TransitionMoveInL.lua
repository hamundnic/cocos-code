
--------------------------------
-- @module TransitionMoveInL
-- @extend TransitionScene,TransitionEaseScene
-- @parent_module cc

--------------------------------
--  returns the action that will be performed 
-- @function [parent=#TransitionMoveInL] action 
-- @param self
-- @return ActionInterval#ActionInterval ret (return value: cc.ActionInterval)
        
--------------------------------
-- 
-- @function [parent=#TransitionMoveInL] easeActionWithAction 
-- @param self
-- @param #cc.ActionInterval action
-- @return ActionInterval#ActionInterval ret (return value: cc.ActionInterval)
        
--------------------------------
-- 
-- @function [parent=#TransitionMoveInL] create 
-- @param self
-- @param #float t
-- @param #cc.Scene scene
-- @return TransitionMoveInL#TransitionMoveInL ret (return value: cc.TransitionMoveInL)
        
return nil
