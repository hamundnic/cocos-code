
--------------------------------
-- @module EventListenerPhysicsContactWithBodies
-- @extend EventListenerPhysicsContact
-- @parent_module cc

--------------------------------
-- 
-- @function [parent=#EventListenerPhysicsContactWithBodies] hitTest 
-- @param self
-- @param #cc.PhysicsShape shapeA
-- @param #cc.PhysicsShape shapeB
-- @return bool#bool ret (return value: bool)
        
--------------------------------
-- 
-- @function [parent=#EventListenerPhysicsContactWithBodies] create 
-- @param self
-- @param #cc.PhysicsBody bodyA
-- @param #cc.PhysicsBody bodyB
-- @return EventListenerPhysicsContactWithBodies#EventListenerPhysicsContactWithBodies ret (return value: cc.EventListenerPhysicsContactWithBodies)
        
--------------------------------
-- 
-- @function [parent=#EventListenerPhysicsContactWithBodies] clone 
-- @param self
-- @return EventListenerPhysicsContactWithBodies#EventListenerPhysicsContactWithBodies ret (return value: cc.EventListenerPhysicsContactWithBodies)
        
return nil
