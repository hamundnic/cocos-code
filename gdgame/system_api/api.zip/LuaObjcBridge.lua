
--------------------------------
-- @module LuaObjcBridge

--------------------------------
-- only for Mac and iOS
-- @function [parent=#LuaObjcBridge] callStaticMethod 
-- @param #string className
-- @param #string methodName
-- @param #table args
-- return bool,int
-- @return int#int ret (return value: int)

return nil