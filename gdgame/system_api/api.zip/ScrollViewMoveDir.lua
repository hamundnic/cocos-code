
--------------------------------
-- @module ScrollViewMoveDir
-- @parent_module ccui

--------------------------------------------------------
-- the ScrollViewMoveDir none
-- @field [parent=#ScrollViewMoveDir] int#int none preloaded module

--------------------------------------------------------
-- the ScrollViewMoveDir up
-- @field [parent=#ScrollViewMoveDir] int#int up preloaded module

--------------------------------------------------------
-- the ScrollViewMoveDir down
-- @field [parent=#ScrollViewMoveDir] int#int down preloaded module

--------------------------------------------------------
-- the ScrollViewMoveDir left
-- @field [parent=#ScrollViewMoveDir] int#int left preloaded module

--------------------------------------------------------
-- the ScrollViewMoveDir right
-- @field [parent=#ScrollViewMoveDir] int#int right preloaded module

return nil