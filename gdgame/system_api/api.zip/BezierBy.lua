
--------------------------------
-- @module BezierBy
-- @extend ActionInterval
-- @parent_module cc

--------------------------------
-- 
-- @function [parent=#BezierBy] startWithTarget 
-- @param self
-- @param #cc.Node target
        
--------------------------------
-- 
-- @function [parent=#BezierBy] clone 
-- @param self
-- @return BezierBy#BezierBy ret (return value: cc.BezierBy)
        
--------------------------------
-- 
-- @function [parent=#BezierBy] reverse 
-- @param self
-- @return BezierBy#BezierBy ret (return value: cc.BezierBy)
        
--------------------------------
-- 
-- @function [parent=#BezierBy] update 
-- @param self
-- @param #float time
   
	



--------------------------------
-- @function [parent=#BezierBy] create 
-- @param self
-- @param #double t
-- @param #point_table points
-- @return BezierBy#BezierBy ret (return value: cc.BezierBy)




return nil
