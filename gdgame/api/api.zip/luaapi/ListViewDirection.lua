
--------------------------------
-- @module ListViewDirection
-- @parent_module ccui

--------------------------------------------------------
-- the ListViewDirection none
-- @field [parent=#ListViewDirection] int#int none preloaded module

--------------------------------------------------------
-- the ListViewDirection vertical
-- @field [parent=#ListViewDirection] int#int vertical preloaded module

--------------------------------------------------------
-- the ListViewDirection horizontal
-- @field [parent=#ListViewDirection] int#int horizontal preloaded module

return nil