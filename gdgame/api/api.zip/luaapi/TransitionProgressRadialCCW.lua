
--------------------------------
-- @module TransitionProgressRadialCCW
-- @extend TransitionProgress
-- @parent_module cc

--------------------------------
-- 
-- @function [parent=#TransitionProgressRadialCCW] create 
-- @param self
-- @param #float t
-- @param #cc.Scene scene
-- @return TransitionProgressRadialCCW#TransitionProgressRadialCCW ret (return value: cc.TransitionProgressRadialCCW)
        
return nil
