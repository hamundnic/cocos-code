
--------------------------------
-- @module EaseCircleActionInOut
-- @extend ActionEase
-- @parent_module cc

--------------------------------
--  creates the action 
-- @function [parent=#EaseCircleActionInOut] create 
-- @param self
-- @param #cc.ActionInterval action
-- @return EaseCircleActionInOut#EaseCircleActionInOut ret (return value: cc.EaseCircleActionInOut)
        
--------------------------------
-- 
-- @function [parent=#EaseCircleActionInOut] clone 
-- @param self
-- @return EaseCircleActionInOut#EaseCircleActionInOut ret (return value: cc.EaseCircleActionInOut)
        
--------------------------------
-- 
-- @function [parent=#EaseCircleActionInOut] update 
-- @param self
-- @param #float time
        
--------------------------------
-- 
-- @function [parent=#EaseCircleActionInOut] reverse 
-- @param self
-- @return EaseCircleActionInOut#EaseCircleActionInOut ret (return value: cc.EaseCircleActionInOut)
        
return nil
