
--------------------------------
-- @module EventListenerAcceleration
-- @extend EventListener
-- @parent_module cc

--------------------------------
-- / Overrides
-- @function [parent=#EventListenerAcceleration] clone 
-- @param self
-- @return EventListenerAcceleration#EventListenerAcceleration ret (return value: cc.EventListenerAcceleration)
        
--------------------------------
-- @function [parent=#EventListenerAcceleration] checkAvailable 
-- @param self
-- @return bool#bool ret (return value: bool)

	



--------------------------------
-- @function [parent=#EventListenerAcceleration] create 
-- @param self
-- @param #function handler
-- @return EventListenerAcceleration#EventListenerAcceleration ret (return value: cc.EventListenerAcceleration)




return nil
