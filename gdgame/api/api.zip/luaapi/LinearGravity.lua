
--------------------------------
-- @module LinearGravity
-- @parent_module ccui

--------------------------------------------------------
-- the LinearGravity none
-- @field [parent=#LinearGravity] int#int none preloaded module

--------------------------------------------------------
-- the LinearGravity left
-- @field [parent=#LinearGravity] int#int left preloaded module

--------------------------------------------------------
-- the LinearGravity top
-- @field [parent=#LinearGravity] int#int top preloaded module

--------------------------------------------------------
-- the LinearGravity right
-- @field [parent=#LinearGravity] int#int right preloaded module

--------------------------------------------------------
-- the LinearGravity bottom
-- @field [parent=#LinearGravity] int#int bottom preloaded module

--------------------------------------------------------
-- the LinearGravity centerVertical
-- @field [parent=#LinearGravity] int#int centerVertical preloaded module

--------------------------------------------------------
-- the LinearGravity centerHorizontal
-- @field [parent=#LinearGravity] int#int centerHorizontal preloaded module

return nil