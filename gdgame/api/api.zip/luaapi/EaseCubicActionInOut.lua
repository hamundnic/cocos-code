
--------------------------------
-- @module EaseCubicActionInOut
-- @extend ActionEase
-- @parent_module cc

--------------------------------
--  creates the action 
-- @function [parent=#EaseCubicActionInOut] create 
-- @param self
-- @param #cc.ActionInterval action
-- @return EaseCubicActionInOut#EaseCubicActionInOut ret (return value: cc.EaseCubicActionInOut)
        
--------------------------------
-- 
-- @function [parent=#EaseCubicActionInOut] clone 
-- @param self
-- @return EaseCubicActionInOut#EaseCubicActionInOut ret (return value: cc.EaseCubicActionInOut)
        
--------------------------------
-- 
-- @function [parent=#EaseCubicActionInOut] update 
-- @param self
-- @param #float time
        
--------------------------------
-- 
-- @function [parent=#EaseCubicActionInOut] reverse 
-- @param self
-- @return EaseCubicActionInOut#EaseCubicActionInOut ret (return value: cc.EaseCubicActionInOut)
        
return nil
