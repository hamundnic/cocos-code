
--------------------------------
-- @module LabelBMFont
-- @extend Node,LabelProtocol,BlendProtocol

--------------------------------
-- @function [parent=#LabelBMFont] setLineBreakWithoutSpace 
-- @param self
-- @param #bool bool
        
--------------------------------
-- @function [parent=#LabelBMFont] getBlendFunc 
-- @param self
-- @return BlendFunc#BlendFunc ret (return value: cc.BlendFunc)
        
--------------------------------
-- @function [parent=#LabelBMFont] isOpacityModifyRGB 
-- @param self
-- @return bool#bool ret (return value: bool)
        
--------------------------------
-- @function [parent=#LabelBMFont] getLetter 
-- @param self
-- @param #int int
-- @return Sprite#Sprite ret (return value: cc.Sprite)
        
--------------------------------
-- @function [parent=#LabelBMFont] getString 
-- @param self
-- @return string#string ret (return value: string)
        
--------------------------------
-- @function [parent=#LabelBMFont] setBlendFunc 
-- @param self
-- @param #cc.BlendFunc blendfunc
        
--------------------------------
-- @function [parent=#LabelBMFont] setString 
-- @param self
-- @param #string str
        
--------------------------------
-- @function [parent=#LabelBMFont] initWithString 
-- @param self
-- @param #string str
-- @param #string str
-- @param #float float
-- @param #cc.TextHAlignment texthalignment
-- @param #vec2_table vec2
-- @return bool#bool ret (return value: bool)
        
--------------------------------
-- @function [parent=#LabelBMFont] setOpacityModifyRGB 
-- @param self
-- @param #bool bool
        
--------------------------------
-- @function [parent=#LabelBMFont] getFntFile 
-- @param self
-- @return string#string ret (return value: string)
        
--------------------------------
-- @function [parent=#LabelBMFont] setFntFile 
-- @param self
-- @param #string str
-- @param #vec2_table vec2
        
--------------------------------
-- @function [parent=#LabelBMFont] setAlignment 
-- @param self
-- @param #cc.TextHAlignment texthalignment
        
--------------------------------
-- @function [parent=#LabelBMFont] setWidth 
-- @param self
-- @param #float float
        
--------------------------------
-- @overload self       
-- @overload self string, string, float, cc.TextHAlignment, vec2_table         
-- @function [parent=#LabelBMFont] create
-- @param self
-- @param #string str
-- @param #string str
-- @param #float float
-- @param #cc.TextHAlignment texthalignment
-- @param #vec2_table vec2
-- @return LabelBMFont#LabelBMFont ret (retunr value: cc.LabelBMFont)

--------------------------------
-- @function [parent=#LabelBMFont] getBoundingBox 
-- @param self
-- @return rect_table#rect_table ret (return value: rect_table)
        
--------------------------------
-- @function [parent=#LabelBMFont] getDescription 
-- @param self
-- @return string#string ret (return value: string)
        
--------------------------------
-- @function [parent=#LabelBMFont] setColor 
-- @param self
-- @param #color3b_table color3b
        
--------------------------------
-- @function [parent=#LabelBMFont] getChildByTag 
-- @param self
-- @param #int int
-- @return Node#Node ret (return value: cc.Node)
        
--------------------------------
-- @function [parent=#LabelBMFont] getContentSize 
-- @param self
-- @return size_table#size_table ret (return value: size_table)
        
--------------------------------
-- @function [parent=#LabelBMFont] LabelBMFont 
-- @param self
        
return nil
