
--------------------------------
-- @module EventListenerPhysicsContact
-- @extend EventListenerCustom
-- @parent_module cc

--------------------------------
--  create the listener 
-- @function [parent=#EventListenerPhysicsContact] create 
-- @param self
-- @return EventListenerPhysicsContact#EventListenerPhysicsContact ret (return value: cc.EventListenerPhysicsContact)
        
--------------------------------
-- 
-- @function [parent=#EventListenerPhysicsContact] clone 
-- @param self
-- @return EventListenerPhysicsContact#EventListenerPhysicsContact ret (return value: cc.EventListenerPhysicsContact)
        
--------------------------------
-- 
-- @function [parent=#EventListenerPhysicsContact] checkAvailable 
-- @param self
-- @return bool#bool ret (return value: bool)
        
return nil
