
--------------------------------
-- @module ScriptHandlerMgr

--------------------------------
-- @function [parent=#ScriptHandlerMgr] getInstance 
-- @param self
-- @return ScriptHandlerMgr#ScriptHandlerMgr ret (return value: ScriptHandlerMgr)

--------------------------------
-- @function [parent=#ScriptHandlerMgr] registerScriptHandler 
-- @param self
-- @param #cc.Ref  ref
-- @param #int handler
-- @param #HandlerType type

--------------------------------
-- @function [parent=#ScriptHandlerMgr] unregisterScriptHandler 
-- @param self
-- @param #cc.Ref  ref
-- @param #HandlerType type


--------------------------------
-- @function [parent=#ScriptHandlerMgr] removeObjectAllHandlers 
-- @param self
-- @param #cc.Ref  ref

return nil