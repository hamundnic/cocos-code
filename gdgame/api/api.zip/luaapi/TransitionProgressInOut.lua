
--------------------------------
-- @module TransitionProgressInOut
-- @extend TransitionProgress
-- @parent_module cc

--------------------------------
-- 
-- @function [parent=#TransitionProgressInOut] create 
-- @param self
-- @param #float t
-- @param #cc.Scene scene
-- @return TransitionProgressInOut#TransitionProgressInOut ret (return value: cc.TransitionProgressInOut)
        
return nil
