
--------------------------------
-- @module PVTouchDir
-- @parent_module ccui

--------------------------------------------------------
-- the PVTouchDir touchLeft
-- @field [parent=#PVTouchDir] int#int touchLeft preloaded module

--------------------------------------------------------
-- the PVTouchDir touchRight
-- @field [parent=#PVTouchDir] int#int touchRight preloaded module

return nil