
--------------------------------
-- @module PhysicsJointRotaryLimit
-- @extend PhysicsJoint
-- @parent_module cc

--------------------------------
-- 
-- @function [parent=#PhysicsJointRotaryLimit] getMax 
-- @param self
-- @return float#float ret (return value: float)
        
--------------------------------
-- 
-- @function [parent=#PhysicsJointRotaryLimit] setMin 
-- @param self
-- @param #float min
        
--------------------------------
-- 
-- @function [parent=#PhysicsJointRotaryLimit] setMax 
-- @param self
-- @param #float max
        
--------------------------------
-- 
-- @function [parent=#PhysicsJointRotaryLimit] getMin 
-- @param self
-- @return float#float ret (return value: float)
        
--------------------------------
-- @overload self, cc.PhysicsBody, cc.PhysicsBody         
-- @overload self, cc.PhysicsBody, cc.PhysicsBody, float, float         
-- @function [parent=#PhysicsJointRotaryLimit] construct
-- @param self
-- @param #cc.PhysicsBody a
-- @param #cc.PhysicsBody b
-- @param #float min
-- @param #float max
-- @return PhysicsJointRotaryLimit#PhysicsJointRotaryLimit ret (retunr value: cc.PhysicsJointRotaryLimit)

return nil
