
--------------------------------
-- @module EaseSineOut
-- @extend ActionEase
-- @parent_module cc

--------------------------------
--  creates the action 
-- @function [parent=#EaseSineOut] create 
-- @param self
-- @param #cc.ActionInterval action
-- @return EaseSineOut#EaseSineOut ret (return value: cc.EaseSineOut)
        
--------------------------------
-- 
-- @function [parent=#EaseSineOut] clone 
-- @param self
-- @return EaseSineOut#EaseSineOut ret (return value: cc.EaseSineOut)
        
--------------------------------
-- 
-- @function [parent=#EaseSineOut] update 
-- @param self
-- @param #float time
        
--------------------------------
-- 
-- @function [parent=#EaseSineOut] reverse 
-- @param self
-- @return ActionEase#ActionEase ret (return value: cc.ActionEase)
        
return nil
