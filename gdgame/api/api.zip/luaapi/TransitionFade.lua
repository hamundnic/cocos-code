
--------------------------------
-- @module TransitionFade
-- @extend TransitionScene
-- @parent_module cc

--------------------------------
-- @overload self, float, cc.Scene         
-- @overload self, float, cc.Scene, color3b_table         
-- @function [parent=#TransitionFade] create
-- @param self
-- @param #float duration
-- @param #cc.Scene scene
-- @param #color3b_table color
-- @return TransitionFade#TransitionFade ret (retunr value: cc.TransitionFade)

return nil
