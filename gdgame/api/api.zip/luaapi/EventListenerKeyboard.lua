
--------------------------------
-- @module EventListenerKeyboard
-- @extend EventListener
-- @parent_module cc

--------------------------------
-- / Overrides
-- @function [parent=#EventListenerKeyboard] clone 
-- @param self
-- @return EventListenerKeyboard#EventListenerKeyboard ret (return value: cc.EventListenerKeyboard)
        
--------------------------------
-- 
-- @function [parent=#EventListenerKeyboard] checkAvailable 
-- @param self
-- @return bool#bool ret (return value: bool)
 
	



--------------------------------
-- @function [parent=#EventListenerKeyboard] create 
-- @param self
-- @return EventListenerKeyboard#EventListenerKeyboard ret (return value: cc.EventListenerKeyboard)

--------------------------------
-- @function [parent=#EventListenerKeyboard] registerScriptHandler 
-- @param self
-- @param #function handler
-- @param #int type





return nil
