
--------------------------------
-- @module vec2_table

--------------------------------------------------------
-- the vec2_table x 
-- @field [parent=#vec2_table] #float x preloaded module

--------------------------------------------------------
-- the vec2_table y 
-- @field [parent=#vec2_table] #float y preloaded module

return nil
