
--------------------------------
-- @module DelayTime
-- @extend ActionInterval
-- @parent_module cc

--------------------------------
--  creates the action 
-- @function [parent=#DelayTime] create 
-- @param self
-- @param #float d
-- @return DelayTime#DelayTime ret (return value: cc.DelayTime)
        
--------------------------------
-- 
-- @function [parent=#DelayTime] clone 
-- @param self
-- @return DelayTime#DelayTime ret (return value: cc.DelayTime)
        
--------------------------------
-- 
-- @function [parent=#DelayTime] update 
-- @param self
-- @param #float time
        
--------------------------------
-- 
-- @function [parent=#DelayTime] reverse 
-- @param self
-- @return DelayTime#DelayTime ret (return value: cc.DelayTime)
        
return nil
