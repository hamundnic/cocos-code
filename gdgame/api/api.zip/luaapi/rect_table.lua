
--------------------------------
-- @module rect_table

--------------------------------------------------------
-- the rect_table x 
-- @field [parent=#rect_table] #float x preloaded module

--------------------------------------------------------
-- the rect_table y 
-- @field [parent=#rect_table] #float y preloaded module

--------------------------------------------------------
-- the rect_table width 
-- @field [parent=#rect_table] #float width preloaded module

--------------------------------------------------------
-- the rect_table height 
-- @field [parent=#rect_table] #float height preloaded module


return nil
