--------------------------------
-- @module ccexp

--------------------------------------------------------
-- the ccexp VideoPlayer
-- @field [parent=#ccexp] VideoPlayer#VideoPlayer VideoPlayer preloaded module


return nil
