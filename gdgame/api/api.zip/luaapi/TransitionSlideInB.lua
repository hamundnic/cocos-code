
--------------------------------
-- @module TransitionSlideInB
-- @extend TransitionSlideInL
-- @parent_module cc

--------------------------------
--  returns the action that will be performed by the incoming and outgoing scene 
-- @function [parent=#TransitionSlideInB] action 
-- @param self
-- @return ActionInterval#ActionInterval ret (return value: cc.ActionInterval)
        
--------------------------------
-- 
-- @function [parent=#TransitionSlideInB] create 
-- @param self
-- @param #float t
-- @param #cc.Scene scene
-- @return TransitionSlideInB#TransitionSlideInB ret (return value: cc.TransitionSlideInB)
        
return nil
