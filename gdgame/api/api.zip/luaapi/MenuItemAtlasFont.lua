
--------------------------------
-- @module MenuItemAtlasFont
-- @extend MenuItemLabel
-- @parent_module cc

return nil
