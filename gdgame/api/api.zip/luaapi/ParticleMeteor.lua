
--------------------------------
-- @module ParticleMeteor
-- @extend ParticleSystemQuad
-- @parent_module cc

--------------------------------
-- 
-- @function [parent=#ParticleMeteor] create 
-- @param self
-- @return ParticleMeteor#ParticleMeteor ret (return value: cc.ParticleMeteor)
        
--------------------------------
-- 
-- @function [parent=#ParticleMeteor] createWithTotalParticles 
-- @param self
-- @param #int numberOfParticles
-- @return ParticleMeteor#ParticleMeteor ret (return value: cc.ParticleMeteor)
        
return nil
