
--------------------------------
-- @module VBox
-- @extend Layout
-- @parent_module ccui

--------------------------------
-- @overload self, size_table         
-- @overload self         
-- @function [parent=#VBox] create
-- @param self
-- @param #size_table size
-- @return VBox#VBox ret (retunr value: ccui.VBox)

--------------------------------
-- Default constructor
-- @function [parent=#VBox] VBox 
-- @param self
        
return nil
