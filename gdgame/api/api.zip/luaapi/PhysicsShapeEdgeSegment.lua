
--------------------------------
-- @module PhysicsShapeEdgeSegment
-- @extend PhysicsShape
-- @parent_module cc

--------------------------------
-- 
-- @function [parent=#PhysicsShapeEdgeSegment] getPointB 
-- @param self
-- @return vec2_table#vec2_table ret (return value: vec2_table)
        
--------------------------------
-- 
-- @function [parent=#PhysicsShapeEdgeSegment] getPointA 
-- @param self
-- @return vec2_table#vec2_table ret (return value: vec2_table)
        
--------------------------------
-- 
-- @function [parent=#PhysicsShapeEdgeSegment] create 
-- @param self
-- @param #vec2_table a
-- @param #vec2_table b
-- @param #cc.PhysicsMaterial material
-- @param #float border
-- @return PhysicsShapeEdgeSegment#PhysicsShapeEdgeSegment ret (return value: cc.PhysicsShapeEdgeSegment)
        
--------------------------------
-- 
-- @function [parent=#PhysicsShapeEdgeSegment] getCenter 
-- @param self
-- @return vec2_table#vec2_table ret (return value: vec2_table)
        
return nil
