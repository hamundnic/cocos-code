
--------------------------------
-- @module EventCode
-- @parent_module cc

--------------------------------------------------------
-- the KeyCode BEGAN 
-- @field [parent=#EventCode] #int BEGAN preloaded module

--------------------------------------------------------
-- the KeyCode MOVED 
-- @field [parent=#EventCode] #int MOVED preloaded module

--------------------------------------------------------
-- the KeyCode ENDED 
-- @field [parent=#EventCode] #int ENDED preloaded module

--------------------------------------------------------
-- the KeyCode CANCELLED 
-- @field [parent=#EventCode] #int CANCELLED preloaded module

return nil
