
--------------------------------
-- @module ColorFrame
-- @extend Frame
-- @parent_module ccs

--------------------------------
-- 
-- @function [parent=#ColorFrame] getAlpha 
-- @param self
-- @return unsigned char#unsigned char ret (return value: unsigned char)
        
--------------------------------
-- 
-- @function [parent=#ColorFrame] getColor 
-- @param self
-- @return color3b_table#color3b_table ret (return value: color3b_table)
        
--------------------------------
-- 
-- @function [parent=#ColorFrame] setAlpha 
-- @param self
-- @param #unsigned char alpha
        
--------------------------------
-- 
-- @function [parent=#ColorFrame] setColor 
-- @param self
-- @param #color3b_table color
        
--------------------------------
-- 
-- @function [parent=#ColorFrame] create 
-- @param self
-- @return ColorFrame#ColorFrame ret (return value: ccs.ColorFrame)
        
--------------------------------
-- 
-- @function [parent=#ColorFrame] apply 
-- @param self
-- @param #float percent
        
--------------------------------
-- 
-- @function [parent=#ColorFrame] clone 
-- @param self
-- @return Frame#Frame ret (return value: ccs.Frame)
        
--------------------------------
-- 
-- @function [parent=#ColorFrame] ColorFrame 
-- @param self
        
return nil
