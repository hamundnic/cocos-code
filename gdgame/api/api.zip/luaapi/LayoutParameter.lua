
--------------------------------
-- @module LayoutParameter
-- @extend Ref
-- @parent_module ccui

--------------------------------
-- 
-- @function [parent=#LayoutParameter] clone 
-- @param self
-- @return LayoutParameter#LayoutParameter ret (return value: ccui.LayoutParameter)
        
--------------------------------
-- Gets LayoutParameterType of LayoutParameter.<br>
-- see LayoutParameterType<br>
-- return LayoutParameterType
-- @function [parent=#LayoutParameter] getLayoutType 
-- @param self
-- @return int#int ret (return value: int)
        
--------------------------------
-- 
-- @function [parent=#LayoutParameter] createCloneInstance 
-- @param self
-- @return LayoutParameter#LayoutParameter ret (return value: ccui.LayoutParameter)
        
--------------------------------
-- 
-- @function [parent=#LayoutParameter] copyProperties 
-- @param self
-- @param #ccui.LayoutParameter model
        
--------------------------------
-- Allocates and initializes.<br>
-- return A initialized LayoutParameter which is marked as "autorelease".
-- @function [parent=#LayoutParameter] create 
-- @param self
-- @return LayoutParameter#LayoutParameter ret (return value: ccui.LayoutParameter)
        
--------------------------------
-- Default constructor
-- @function [parent=#LayoutParameter] LayoutParameter 
-- @param self

	


--------------------------------
-- @function [parent=#LayoutParameter] setMargin 
-- @param self
-- @param #margin_table margin 

--------------------------------
-- @function [parent=#LayoutParameter] getMargin 
-- @param self
-- @return table#table ret (return value : margin_table)s




return nil
