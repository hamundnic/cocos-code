
--------------------------------
-- @module TransitionProgressHorizontal
-- @extend TransitionProgress
-- @parent_module cc

--------------------------------
-- 
-- @function [parent=#TransitionProgressHorizontal] create 
-- @param self
-- @param #float t
-- @param #cc.Scene scene
-- @return TransitionProgressHorizontal#TransitionProgressHorizontal ret (return value: cc.TransitionProgressHorizontal)
        
return nil
