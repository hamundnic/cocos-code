
--------------------------------
-- @module EventTouch
-- @extend Event
-- @parent_module cc

--------------------------------
-- 
-- @function [parent=#EventTouch] getEventCode 
-- @param self
-- @return int#int ret (return value: int)
        
--------------------------------
-- 
-- @function [parent=#EventTouch] setEventCode 
-- @param self
-- @param #int eventCode
        
--------------------------------
-- 
-- @function [parent=#EventTouch] EventTouch 
-- @param self
        
return nil
