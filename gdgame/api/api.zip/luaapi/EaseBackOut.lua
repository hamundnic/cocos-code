
--------------------------------
-- @module EaseBackOut
-- @extend ActionEase
-- @parent_module cc

--------------------------------
--  creates the action 
-- @function [parent=#EaseBackOut] create 
-- @param self
-- @param #cc.ActionInterval action
-- @return EaseBackOut#EaseBackOut ret (return value: cc.EaseBackOut)
        
--------------------------------
-- 
-- @function [parent=#EaseBackOut] clone 
-- @param self
-- @return EaseBackOut#EaseBackOut ret (return value: cc.EaseBackOut)
        
--------------------------------
-- 
-- @function [parent=#EaseBackOut] update 
-- @param self
-- @param #float time
        
--------------------------------
-- 
-- @function [parent=#EaseBackOut] reverse 
-- @param self
-- @return ActionEase#ActionEase ret (return value: cc.ActionEase)
        
return nil
