
--------------------------------
-- @module TransitionMoveInB
-- @extend TransitionMoveInL
-- @parent_module cc

--------------------------------
-- 
-- @function [parent=#TransitionMoveInB] create 
-- @param self
-- @param #float t
-- @param #cc.Scene scene
-- @return TransitionMoveInB#TransitionMoveInB ret (return value: cc.TransitionMoveInB)
        
return nil
