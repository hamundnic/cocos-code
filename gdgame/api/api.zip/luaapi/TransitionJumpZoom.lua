
--------------------------------
-- @module TransitionJumpZoom
-- @extend TransitionScene
-- @parent_module cc

--------------------------------
-- 
-- @function [parent=#TransitionJumpZoom] create 
-- @param self
-- @param #float t
-- @param #cc.Scene scene
-- @return TransitionJumpZoom#TransitionJumpZoom ret (return value: cc.TransitionJumpZoom)
        
return nil
