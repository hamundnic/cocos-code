
--------------------------------
-- @module EaseCircleActionIn
-- @extend ActionEase
-- @parent_module cc

--------------------------------
--  creates the action 
-- @function [parent=#EaseCircleActionIn] create 
-- @param self
-- @param #cc.ActionInterval action
-- @return EaseCircleActionIn#EaseCircleActionIn ret (return value: cc.EaseCircleActionIn)
        
--------------------------------
-- 
-- @function [parent=#EaseCircleActionIn] clone 
-- @param self
-- @return EaseCircleActionIn#EaseCircleActionIn ret (return value: cc.EaseCircleActionIn)
        
--------------------------------
-- 
-- @function [parent=#EaseCircleActionIn] update 
-- @param self
-- @param #float time
        
--------------------------------
-- 
-- @function [parent=#EaseCircleActionIn] reverse 
-- @param self
-- @return EaseCircleActionIn#EaseCircleActionIn ret (return value: cc.EaseCircleActionIn)
        
return nil
