--------------------------------
-- @module ccexp

--------------------------------------------------------
-- the ccexp VideoPlayer
-- @field [parent=#ccexp] VideoPlayer#VideoPlayer VideoPlayer preloaded module


--------------------------------------------------------
-- the ccexp VideoPlayerEvent
-- @field [parent=#ccexp] VideoPlayerEvent#VideoPlayerEvent VideoPlayerEvent preloaded module


--------------------------------------------------------
-- the ccexp TMXTiledMap
-- @field [parent=#ccexp] TMXTiledMap#TMXTiledMap TMXTiledMap preloaded module


--------------------------------------------------------
-- the ccexp TMXLayer
-- @field [parent=#ccexp] TMXLayer#TMXLayer TMXLayer preloaded module

return nil
