--------------------------------
-- @module ct

--------------------------------------------------------
-- the ct CustomClass
-- @field [parent=#ct] CustomClass#CustomClass CustomClass preloaded module

--------------------------------------------------------
-- the ct MaskSprite
-- @field [parent=#ct] MaskSprite#MaskSprite MaskSprite preloaded module

return nil
