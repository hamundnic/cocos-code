
--------------------------------
-- @module ArmatureData
-- @extend Ref
-- @parent_module ccs

--------------------------------
-- 
-- @function [parent=#ArmatureData] addBoneData 
-- @param self
-- @param #ccs.BoneData boneData
        
--------------------------------
-- 
-- @function [parent=#ArmatureData] init 
-- @param self
-- @return bool#bool ret (return value: bool)
        
--------------------------------
-- 
-- @function [parent=#ArmatureData] getBoneData 
-- @param self
-- @param #string boneName
-- @return BoneData#BoneData ret (return value: ccs.BoneData)
        
--------------------------------
-- 
-- @function [parent=#ArmatureData] create 
-- @param self
-- @return ArmatureData#ArmatureData ret (return value: ccs.ArmatureData)
        
--------------------------------
-- js ctor
-- @function [parent=#ArmatureData] ArmatureData 
-- @param self
        
return nil
