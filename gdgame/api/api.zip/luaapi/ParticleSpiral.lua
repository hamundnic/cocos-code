
--------------------------------
-- @module ParticleSpiral
-- @extend ParticleSystemQuad
-- @parent_module cc

--------------------------------
-- 
-- @function [parent=#ParticleSpiral] create 
-- @param self
-- @return ParticleSpiral#ParticleSpiral ret (return value: cc.ParticleSpiral)
        
--------------------------------
-- 
-- @function [parent=#ParticleSpiral] createWithTotalParticles 
-- @param self
-- @param #int numberOfParticles
-- @return ParticleSpiral#ParticleSpiral ret (return value: cc.ParticleSpiral)
        
return nil
