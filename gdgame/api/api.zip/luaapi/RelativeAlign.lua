
--------------------------------
-- @module RelativeAlign
-- @parent_module ccui

--------------------------------------------------------
-- the RelativeAlign alignNone
-- @field [parent=#RelativeAlign] int#int alignNone preloaded module

--------------------------------------------------------
-- the RelativeAlign alignParentTopLeft
-- @field [parent=#RelativeAlign] int#int alignParentTopLeft preloaded module

--------------------------------------------------------
-- the RelativeAlign alignParentTopCenterHorizontal
-- @field [parent=#RelativeAlign] int#int alignParentTopCenterHorizontal preloaded module

--------------------------------------------------------
-- the RelativeAlign alignParentTopRight
-- @field [parent=#RelativeAlign] int#int alignParentTopRight preloaded module

--------------------------------------------------------
-- the RelativeAlign alignParentLeftCenterVertical
-- @field [parent=#RelativeAlign] int#int alignParentLeftCenterVertical preloaded module

--------------------------------------------------------
-- the RelativeAlign centerInParent
-- @field [parent=#RelativeAlign] int#int centerInParent preloaded module

--------------------------------------------------------
-- the RelativeAlign alignParentRightCenterVertical
-- @field [parent=#RelativeAlign] int#int alignParentRightCenterVertical preloaded module

--------------------------------------------------------
-- the RelativeAlign alignParentLeftBottom
-- @field [parent=#RelativeAlign] int#int alignParentLeftBottom preloaded module

--------------------------------------------------------
-- the RelativeAlign alignParentBottomCenterHorizontal
-- @field [parent=#RelativeAlign] int#int alignParentBottomCenterHorizontal preloaded module

--------------------------------------------------------
-- the RelativeAlign alignParentRightBottom
-- @field [parent=#RelativeAlign] int#int alignParentRightBottom preloaded module

--------------------------------------------------------
-- the RelativeAlign locationAboveLeftAlign
-- @field [parent=#RelativeAlign] int#int locationAboveLeftAlign preloaded module

--------------------------------------------------------
-- the RelativeAlign locationAboveCenter
-- @field [parent=#RelativeAlign] int#int locationAboveCenter preloaded module

--------------------------------------------------------
-- the RelativeAlign locationAboveRightAlign
-- @field [parent=#RelativeAlign] int#int locationAboveRightAlign preloaded module

--------------------------------------------------------
-- the RelativeAlign locationLeftOfTopAlign
-- @field [parent=#RelativeAlign] int#int locationLeftOfTopAlign preloaded module

--------------------------------------------------------
-- the RelativeAlign locationLeftOfCenter
-- @field [parent=#RelativeAlign] int#int locationLeftOfCenter preloaded module

--------------------------------------------------------
-- the RelativeAlign locationLeftOfBottomAlign
-- @field [parent=#RelativeAlign] int#int locationLeftOfBottomAlign preloaded module

--------------------------------------------------------
-- the RelativeAlign locationRightOfTopAlign
-- @field [parent=#RelativeAlign] int#int locationRightOfTopAlign preloaded module

--------------------------------------------------------
-- the RelativeAlign locationRightOfCenter
-- @field [parent=#RelativeAlign] int#int locationRightOfCenter preloaded module

--------------------------------------------------------
-- the RelativeAlign locationRightOfBottomAlign
-- @field [parent=#RelativeAlign] int#int locationRightOfBottomAlign preloaded module

--------------------------------------------------------
-- the RelativeAlign locationBelowLeftAlign
-- @field [parent=#RelativeAlign] int#int locationBelowLeftAlign preloaded module

--------------------------------------------------------
-- the RelativeAlign locationBelowCenter
-- @field [parent=#RelativeAlign] int#int locationBelowCenter preloaded module

--------------------------------------------------------
-- the RelativeAlign locationBelowRightAlign
-- @field [parent=#RelativeAlign] int#int locationBelowRightAlign preloaded module

return nil