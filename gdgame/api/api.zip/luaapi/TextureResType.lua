
--------------------------------
-- @module TextureResType
-- @parent_module ccui

--------------------------------------------------------
-- the WidgetType localType
-- @field [parent=#TextureResType] int#int localType preloaded module

--------------------------------------------------------
-- the WidgetType plistType
-- @field [parent=#TextureResType] int#int plistType preloaded module

return nil