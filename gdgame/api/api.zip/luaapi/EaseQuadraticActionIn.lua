
--------------------------------
-- @module EaseQuadraticActionIn
-- @extend ActionEase
-- @parent_module cc

--------------------------------
--  creates the action 
-- @function [parent=#EaseQuadraticActionIn] create 
-- @param self
-- @param #cc.ActionInterval action
-- @return EaseQuadraticActionIn#EaseQuadraticActionIn ret (return value: cc.EaseQuadraticActionIn)
        
--------------------------------
-- 
-- @function [parent=#EaseQuadraticActionIn] clone 
-- @param self
-- @return EaseQuadraticActionIn#EaseQuadraticActionIn ret (return value: cc.EaseQuadraticActionIn)
        
--------------------------------
-- 
-- @function [parent=#EaseQuadraticActionIn] update 
-- @param self
-- @param #float time
        
--------------------------------
-- 
-- @function [parent=#EaseQuadraticActionIn] reverse 
-- @param self
-- @return EaseQuadraticActionIn#EaseQuadraticActionIn ret (return value: cc.EaseQuadraticActionIn)
        
return nil
