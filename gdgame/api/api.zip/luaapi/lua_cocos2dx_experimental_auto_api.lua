--------------------------------
-- @module ccexp

--------------------------------------------------------
-- the ccexp TMXLayer
-- @field [parent=#ccexp] TMXLayer#TMXLayer TMXLayer preloaded module


--------------------------------------------------------
-- the ccexp TMXTiledMap
-- @field [parent=#ccexp] TMXTiledMap#TMXTiledMap TMXTiledMap preloaded module


return nil
