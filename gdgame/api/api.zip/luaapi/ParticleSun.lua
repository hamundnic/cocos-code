
--------------------------------
-- @module ParticleSun
-- @extend ParticleSystemQuad
-- @parent_module cc

--------------------------------
-- 
-- @function [parent=#ParticleSun] create 
-- @param self
-- @return ParticleSun#ParticleSun ret (return value: cc.ParticleSun)
        
--------------------------------
-- 
-- @function [parent=#ParticleSun] createWithTotalParticles 
-- @param self
-- @param #int numberOfParticles
-- @return ParticleSun#ParticleSun ret (return value: cc.ParticleSun)
        
return nil
