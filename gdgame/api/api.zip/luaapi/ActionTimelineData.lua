
--------------------------------
-- @module ActionTimelineData
-- @extend Ref
-- @parent_module ccs

--------------------------------
-- 
-- @function [parent=#ActionTimelineData] setActionTag 
-- @param self
-- @param #int actionTag
        
--------------------------------
-- 
-- @function [parent=#ActionTimelineData] getActionTag 
-- @param self
-- @return int#int ret (return value: int)
        
--------------------------------
-- 
-- @function [parent=#ActionTimelineData] create 
-- @param self
-- @param #int actionTag
-- @return ActionTimelineData#ActionTimelineData ret (return value: ccs.ActionTimelineData)
        
return nil
