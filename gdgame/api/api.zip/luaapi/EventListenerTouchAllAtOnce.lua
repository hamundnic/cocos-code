
--------------------------------
-- @module EventListenerTouchAllAtOnce
-- @extend EventListener
-- @parent_module cc

--------------------------------
-- / Overrides
-- @function [parent=#EventListenerTouchAllAtOnce] clone 
-- @param self
-- @return EventListenerTouchAllAtOnce#EventListenerTouchAllAtOnce ret (return value: cc.EventListenerTouchAllAtOnce)
        
--------------------------------
-- 
-- @function [parent=#EventListenerTouchAllAtOnce] checkAvailable 
-- @param self
-- @return bool#bool ret (return value: bool)
  
	


--------------------------------
-- @function [parent=#EventListenerTouchAllAtOnce] create 
-- @param self
-- @return EventListenerTouchAllAtOnce#EventListenerTouchAllAtOnce ret (return value: cc.EventListenerTouchAllAtOnce)

--------------------------------
-- @function [parent=#EventListenerTouchAllAtOnce] registerScriptHandler 
-- @param self
-- @param #function handler
-- @param #int type





return nil
