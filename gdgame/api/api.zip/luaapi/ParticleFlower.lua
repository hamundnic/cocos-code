
--------------------------------
-- @module ParticleFlower
-- @extend ParticleSystemQuad
-- @parent_module cc

--------------------------------
-- 
-- @function [parent=#ParticleFlower] create 
-- @param self
-- @return ParticleFlower#ParticleFlower ret (return value: cc.ParticleFlower)
        
--------------------------------
-- 
-- @function [parent=#ParticleFlower] createWithTotalParticles 
-- @param self
-- @param #int numberOfParticles
-- @return ParticleFlower#ParticleFlower ret (return value: cc.ParticleFlower)
        
return nil
