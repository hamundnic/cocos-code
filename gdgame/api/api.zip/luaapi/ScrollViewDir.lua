
--------------------------------
-- @module ScrollViewDir
-- @parent_module ccui

--------------------------------------------------------
-- the ScrollViewDir none
-- @field [parent=#ScrollViewDir] int#int none preloaded module

--------------------------------------------------------
-- the ScrollViewDir vertical
-- @field [parent=#ScrollViewDir] int#int vertical preloaded module

--------------------------------------------------------
-- the ScrollViewDir horizontal
-- @field [parent=#ScrollViewDir] int#int horizontal preloaded module

--------------------------------------------------------
-- the ScrollViewDir both
-- @field [parent=#ScrollViewDir] int#int both preloaded module

return nil