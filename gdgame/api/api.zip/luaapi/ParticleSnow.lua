
--------------------------------
-- @module ParticleSnow
-- @extend ParticleSystemQuad
-- @parent_module cc

--------------------------------
-- 
-- @function [parent=#ParticleSnow] create 
-- @param self
-- @return ParticleSnow#ParticleSnow ret (return value: cc.ParticleSnow)
        
--------------------------------
-- 
-- @function [parent=#ParticleSnow] createWithTotalParticles 
-- @param self
-- @param #int numberOfParticles
-- @return ParticleSnow#ParticleSnow ret (return value: cc.ParticleSnow)
        
return nil
