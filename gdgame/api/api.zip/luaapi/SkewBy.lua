
--------------------------------
-- @module SkewBy
-- @extend SkewTo
-- @parent_module cc

--------------------------------
--  creates the action 
-- @function [parent=#SkewBy] create 
-- @param self
-- @param #float t
-- @param #float deltaSkewX
-- @param #float deltaSkewY
-- @return SkewBy#SkewBy ret (return value: cc.SkewBy)
        
--------------------------------
-- 
-- @function [parent=#SkewBy] startWithTarget 
-- @param self
-- @param #cc.Node target
        
--------------------------------
-- 
-- @function [parent=#SkewBy] clone 
-- @param self
-- @return SkewBy#SkewBy ret (return value: cc.SkewBy)
        
--------------------------------
-- 
-- @function [parent=#SkewBy] reverse 
-- @param self
-- @return SkewBy#SkewBy ret (return value: cc.SkewBy)
        
return nil
