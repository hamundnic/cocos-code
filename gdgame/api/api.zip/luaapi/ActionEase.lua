
--------------------------------
-- @module ActionEase
-- @extend ActionInterval
-- @parent_module cc

--------------------------------
-- 
-- @function [parent=#ActionEase] getInnerAction 
-- @param self
-- @return ActionInterval#ActionInterval ret (return value: cc.ActionInterval)
        
--------------------------------
-- 
-- @function [parent=#ActionEase] startWithTarget 
-- @param self
-- @param #cc.Node target
        
--------------------------------
-- 
-- @function [parent=#ActionEase] clone 
-- @param self
-- @return ActionEase#ActionEase ret (return value: cc.ActionEase)
        
--------------------------------
-- 
-- @function [parent=#ActionEase] stop 
-- @param self
        
--------------------------------
-- 
-- @function [parent=#ActionEase] reverse 
-- @param self
-- @return ActionEase#ActionEase ret (return value: cc.ActionEase)
        
--------------------------------
-- 
-- @function [parent=#ActionEase] update 
-- @param self
-- @param #float time
        
return nil
