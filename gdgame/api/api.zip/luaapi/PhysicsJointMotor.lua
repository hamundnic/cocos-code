
--------------------------------
-- @module PhysicsJointMotor
-- @extend PhysicsJoint
-- @parent_module cc

--------------------------------
-- 
-- @function [parent=#PhysicsJointMotor] setRate 
-- @param self
-- @param #float rate
        
--------------------------------
-- 
-- @function [parent=#PhysicsJointMotor] getRate 
-- @param self
-- @return float#float ret (return value: float)
        
--------------------------------
-- 
-- @function [parent=#PhysicsJointMotor] construct 
-- @param self
-- @param #cc.PhysicsBody a
-- @param #cc.PhysicsBody b
-- @param #float rate
-- @return PhysicsJointMotor#PhysicsJointMotor ret (return value: cc.PhysicsJointMotor)
        
return nil
