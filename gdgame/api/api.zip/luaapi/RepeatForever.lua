
--------------------------------
-- @module RepeatForever
-- @extend ActionInterval
-- @parent_module cc

--------------------------------
-- 
-- @function [parent=#RepeatForever] setInnerAction 
-- @param self
-- @param #cc.ActionInterval action
        
--------------------------------
-- 
-- @function [parent=#RepeatForever] getInnerAction 
-- @param self
-- @return ActionInterval#ActionInterval ret (return value: cc.ActionInterval)
        
--------------------------------
--  creates the action 
-- @function [parent=#RepeatForever] create 
-- @param self
-- @param #cc.ActionInterval action
-- @return RepeatForever#RepeatForever ret (return value: cc.RepeatForever)
        
--------------------------------
-- 
-- @function [parent=#RepeatForever] startWithTarget 
-- @param self
-- @param #cc.Node target
        
--------------------------------
-- 
-- @function [parent=#RepeatForever] clone 
-- @param self
-- @return RepeatForever#RepeatForever ret (return value: cc.RepeatForever)
        
--------------------------------
-- 
-- @function [parent=#RepeatForever] isDone 
-- @param self
-- @return bool#bool ret (return value: bool)
        
--------------------------------
-- 
-- @function [parent=#RepeatForever] reverse 
-- @param self
-- @return RepeatForever#RepeatForever ret (return value: cc.RepeatForever)
        
--------------------------------
-- 
-- @function [parent=#RepeatForever] step 
-- @param self
-- @param #float dt
        
return nil
