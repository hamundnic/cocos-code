
--------------------------------
-- @module TransitionMoveInR
-- @extend TransitionMoveInL
-- @parent_module cc

--------------------------------
-- 
-- @function [parent=#TransitionMoveInR] create 
-- @param self
-- @param #float t
-- @param #cc.Scene scene
-- @return TransitionMoveInR#TransitionMoveInR ret (return value: cc.TransitionMoveInR)
        
return nil
