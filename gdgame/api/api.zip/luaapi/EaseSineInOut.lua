
--------------------------------
-- @module EaseSineInOut
-- @extend ActionEase
-- @parent_module cc

--------------------------------
--  creates the action 
-- @function [parent=#EaseSineInOut] create 
-- @param self
-- @param #cc.ActionInterval action
-- @return EaseSineInOut#EaseSineInOut ret (return value: cc.EaseSineInOut)
        
--------------------------------
-- 
-- @function [parent=#EaseSineInOut] clone 
-- @param self
-- @return EaseSineInOut#EaseSineInOut ret (return value: cc.EaseSineInOut)
        
--------------------------------
-- 
-- @function [parent=#EaseSineInOut] update 
-- @param self
-- @param #float time
        
--------------------------------
-- 
-- @function [parent=#EaseSineInOut] reverse 
-- @param self
-- @return EaseSineInOut#EaseSineInOut ret (return value: cc.EaseSineInOut)
        
return nil
