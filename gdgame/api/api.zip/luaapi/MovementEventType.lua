
--------------------------------
-- @module MovementEventType
-- @parent_module ccs

--------------------------------------------------------
-- the MovementEventType start
-- @field [parent=#MovementEventType] int#int start preloaded module

--------------------------------------------------------
-- the MovementEventType complete
-- @field [parent=#MovementEventType] int#int complete preloaded module

--------------------------------------------------------
-- the MovementEventType loopComplete
-- @field [parent=#MovementEventType] int#int loopComplete preloaded module

return nil