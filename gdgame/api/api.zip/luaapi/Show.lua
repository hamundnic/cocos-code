
--------------------------------
-- @module Show
-- @extend ActionInstant
-- @parent_module cc

--------------------------------
--  Allocates and initializes the action 
-- @function [parent=#Show] create 
-- @param self
-- @return Show#Show ret (return value: cc.Show)
        
--------------------------------
-- 
-- @function [parent=#Show] clone 
-- @param self
-- @return Show#Show ret (return value: cc.Show)
        
--------------------------------
-- 
-- @function [parent=#Show] update 
-- @param self
-- @param #float time
        
--------------------------------
-- 
-- @function [parent=#Show] reverse 
-- @param self
-- @return ActionInstant#ActionInstant ret (return value: cc.ActionInstant)
        
return nil
