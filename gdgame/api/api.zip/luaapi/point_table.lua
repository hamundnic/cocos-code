
--------------------------------
-- @module point_table

--------------------------------------------------------
-- the point_table x 
-- @field [parent=#point_table] #float x preloaded module

--------------------------------------------------------
-- the point_table y 
-- @field [parent=#point_table] #float y preloaded module

return nil
