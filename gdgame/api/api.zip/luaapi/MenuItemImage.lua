
--------------------------------
-- @module MenuItemImage
-- @extend MenuItemSprite
-- @parent_module cc

--------------------------------
--  sets the sprite frame for the disabled image 
-- @function [parent=#MenuItemImage] setDisabledSpriteFrame 
-- @param self
-- @param #cc.SpriteFrame frame
        
--------------------------------
--  sets the sprite frame for the selected image 
-- @function [parent=#MenuItemImage] setSelectedSpriteFrame 
-- @param self
-- @param #cc.SpriteFrame frame
        
--------------------------------
--  sets the sprite frame for the normal image 
-- @function [parent=#MenuItemImage] setNormalSpriteFrame 
-- @param self
-- @param #cc.SpriteFrame frame
    
	



--------------------------------
-- @overload self         
-- @overload self, normalImage, selectedImage, disabledImage
-- @function [parent=#MenuItemImage] create 
-- @param self
-- @param #string normalImage
-- @param #string selectedImage
-- @param #string disabledImage
-- @return MenuItemImage#MenuItemImage ret (return value: cc.MenuItemImage)





return nil
