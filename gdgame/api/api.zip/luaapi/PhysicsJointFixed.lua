
--------------------------------
-- @module PhysicsJointFixed
-- @extend PhysicsJoint
-- @parent_module cc

--------------------------------
-- 
-- @function [parent=#PhysicsJointFixed] construct 
-- @param self
-- @param #cc.PhysicsBody a
-- @param #cc.PhysicsBody b
-- @param #vec2_table anchr
-- @return PhysicsJointFixed#PhysicsJointFixed ret (return value: cc.PhysicsJointFixed)
        
return nil
