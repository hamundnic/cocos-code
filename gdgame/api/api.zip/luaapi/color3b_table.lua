
--------------------------------
-- @module color3b_table

--------------------------------------------------------
-- the color3b_table r 
-- @field [parent=#color3b_table] #uchar r preloaded module

--------------------------------------------------------
-- the color3b_table g 
-- @field [parent=#color3b_table] #uchar g preloaded module

--------------------------------------------------------
-- the color3b_table b 
-- @field [parent=#color3b_table] #uchar b preloaded module

return nil
