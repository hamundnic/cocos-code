
--------------------------------
-- @module FadeTo
-- @extend ActionInterval
-- @parent_module cc

--------------------------------
--  creates an action with duration and opacity 
-- @function [parent=#FadeTo] create 
-- @param self
-- @param #float duration
-- @param #unsigned char opacity
-- @return FadeTo#FadeTo ret (return value: cc.FadeTo)
        
--------------------------------
-- 
-- @function [parent=#FadeTo] startWithTarget 
-- @param self
-- @param #cc.Node target
        
--------------------------------
-- 
-- @function [parent=#FadeTo] clone 
-- @param self
-- @return FadeTo#FadeTo ret (return value: cc.FadeTo)
        
--------------------------------
-- 
-- @function [parent=#FadeTo] reverse 
-- @param self
-- @return FadeTo#FadeTo ret (return value: cc.FadeTo)
        
--------------------------------
-- 
-- @function [parent=#FadeTo] update 
-- @param self
-- @param #float time
        
return nil
