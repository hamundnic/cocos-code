
--------------------------------
-- @module EventFocus
-- @extend Event
-- @parent_module cc

--------------------------------
-- 
-- @function [parent=#EventFocus] EventFocus 
-- @param self
-- @param #ccui.Widget widgetLoseFocus
-- @param #ccui.Widget widgetGetFocus
        
return nil
