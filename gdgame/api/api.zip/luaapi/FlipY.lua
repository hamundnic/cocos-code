
--------------------------------
-- @module FlipY
-- @extend ActionInstant
-- @parent_module cc

--------------------------------
--  create the action 
-- @function [parent=#FlipY] create 
-- @param self
-- @param #bool y
-- @return FlipY#FlipY ret (return value: cc.FlipY)
        
--------------------------------
-- 
-- @function [parent=#FlipY] clone 
-- @param self
-- @return FlipY#FlipY ret (return value: cc.FlipY)
        
--------------------------------
-- 
-- @function [parent=#FlipY] update 
-- @param self
-- @param #float time
        
--------------------------------
-- 
-- @function [parent=#FlipY] reverse 
-- @param self
-- @return FlipY#FlipY ret (return value: cc.FlipY)
        
return nil
