
--------------------------------
-- @module TouchEventType
-- @parent_module ccui

--------------------------------------------------------
-- the TouchEventType began
-- @field [parent=#TouchEventType] int#int began preloaded module

--------------------------------------------------------
-- the TouchEventType moved
-- @field [parent=#TouchEventType] int#int moved preloaded module

--------------------------------------------------------
-- the TouchEventType ended
-- @field [parent=#TouchEventType] int#int ended preloaded module

--------------------------------------------------------
-- the TouchEventType canceled
-- @field [parent=#TouchEventType] int#int canceled preloaded module

return nil