
--------------------------------
-- @module EaseRateAction
-- @extend ActionEase
-- @parent_module cc

--------------------------------
--  set rate value for the actions 
-- @function [parent=#EaseRateAction] setRate 
-- @param self
-- @param #float rate
        
--------------------------------
--  get rate value for the actions 
-- @function [parent=#EaseRateAction] getRate 
-- @param self
-- @return float#float ret (return value: float)
        
--------------------------------
-- 
-- @function [parent=#EaseRateAction] clone 
-- @param self
-- @return EaseRateAction#EaseRateAction ret (return value: cc.EaseRateAction)
        
--------------------------------
-- 
-- @function [parent=#EaseRateAction] reverse 
-- @param self
-- @return EaseRateAction#EaseRateAction ret (return value: cc.EaseRateAction)
        
return nil
