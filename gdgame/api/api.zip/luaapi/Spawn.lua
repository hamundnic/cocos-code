
--------------------------------
-- @module Spawn
-- @extend ActionInterval
-- @parent_module cc

--------------------------------
-- 
-- @function [parent=#Spawn] startWithTarget 
-- @param self
-- @param #cc.Node target
        
--------------------------------
-- 
-- @function [parent=#Spawn] clone 
-- @param self
-- @return Spawn#Spawn ret (return value: cc.Spawn)
        
--------------------------------
-- 
-- @function [parent=#Spawn] stop 
-- @param self
        
--------------------------------
-- 
-- @function [parent=#Spawn] reverse 
-- @param self
-- @return Spawn#Spawn ret (return value: cc.Spawn)
        
--------------------------------
-- 
-- @function [parent=#Spawn] update 
-- @param self
-- @param #float time
    
	



--------------------------------
-- @overload self, table         
-- @overload self, cc.FiniteTimeAction, cc.FiniteTimeAction
-- @function [parent=#Spawn] create 
-- @param self
-- @param #cc.FiniteTimeAction action
-- @param #cc.FiniteTimeAction action
-- @param #cc.FiniteTimeAction action ...
-- @return Spawn#Spawn ret (return value: cc.Spawn)






return nil
