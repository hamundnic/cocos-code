
--------------------------------
-- @module ParticleRain
-- @extend ParticleSystemQuad
-- @parent_module cc

--------------------------------
-- 
-- @function [parent=#ParticleRain] create 
-- @param self
-- @return ParticleRain#ParticleRain ret (return value: cc.ParticleRain)
        
--------------------------------
-- 
-- @function [parent=#ParticleRain] createWithTotalParticles 
-- @param self
-- @param #int numberOfParticles
-- @return ParticleRain#ParticleRain ret (return value: cc.ParticleRain)
        
return nil
