
--------------------------------
-- @module TransitionSplitCols
-- @extend TransitionScene,TransitionEaseScene
-- @parent_module cc

--------------------------------
-- 
-- @function [parent=#TransitionSplitCols] action 
-- @param self
-- @return ActionInterval#ActionInterval ret (return value: cc.ActionInterval)
        
--------------------------------
-- 
-- @function [parent=#TransitionSplitCols] easeActionWithAction 
-- @param self
-- @param #cc.ActionInterval action
-- @return ActionInterval#ActionInterval ret (return value: cc.ActionInterval)
        
--------------------------------
-- 
-- @function [parent=#TransitionSplitCols] create 
-- @param self
-- @param #float t
-- @param #cc.Scene scene
-- @return TransitionSplitCols#TransitionSplitCols ret (return value: cc.TransitionSplitCols)
        
--------------------------------
-- 
-- @function [parent=#TransitionSplitCols] draw 
-- @param self
-- @param #cc.Renderer renderer
-- @param #mat4_table transform
-- @param #unsigned int flags
        
return nil
