--------------------------------
-- @module PageViewEventType
-- @parent_module ccui

--------------------------------------------------------
-- the PageViewEventType turning
-- @field [parent=#PageViewEventType] int#int turning preloaded module

return nil