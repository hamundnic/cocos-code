
--------------------------------
-- @module EaseBounceInOut
-- @extend EaseBounce
-- @parent_module cc

--------------------------------
--  creates the action 
-- @function [parent=#EaseBounceInOut] create 
-- @param self
-- @param #cc.ActionInterval action
-- @return EaseBounceInOut#EaseBounceInOut ret (return value: cc.EaseBounceInOut)
        
--------------------------------
-- 
-- @function [parent=#EaseBounceInOut] clone 
-- @param self
-- @return EaseBounceInOut#EaseBounceInOut ret (return value: cc.EaseBounceInOut)
        
--------------------------------
-- 
-- @function [parent=#EaseBounceInOut] update 
-- @param self
-- @param #float time
        
--------------------------------
-- 
-- @function [parent=#EaseBounceInOut] reverse 
-- @param self
-- @return EaseBounceInOut#EaseBounceInOut ret (return value: cc.EaseBounceInOut)
        
return nil
