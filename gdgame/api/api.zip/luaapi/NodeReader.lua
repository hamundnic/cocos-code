
--------------------------------
-- @module NodeReader
-- @parent_module ccs

--------------------------------
-- 
-- @function [parent=#NodeReader] setJsonPath 
-- @param self
-- @param #string jsonPath
        
--------------------------------
-- 
-- @function [parent=#NodeReader] createNode 
-- @param self
-- @param #string filename
-- @return Node#Node ret (return value: cc.Node)
        
--------------------------------
-- 
-- @function [parent=#NodeReader] loadNodeWithFile 
-- @param self
-- @param #string fileName
-- @return Node#Node ret (return value: cc.Node)
        
--------------------------------
-- 
-- @function [parent=#NodeReader] purge 
-- @param self
        
--------------------------------
-- 
-- @function [parent=#NodeReader] init 
-- @param self
        
--------------------------------
-- 
-- @function [parent=#NodeReader] loadNodeWithContent 
-- @param self
-- @param #string content
-- @return Node#Node ret (return value: cc.Node)
        
--------------------------------
-- 
-- @function [parent=#NodeReader] isRecordJsonPath 
-- @param self
-- @return bool#bool ret (return value: bool)
        
--------------------------------
-- 
-- @function [parent=#NodeReader] getJsonPath 
-- @param self
-- @return string#string ret (return value: string)
        
--------------------------------
-- 
-- @function [parent=#NodeReader] setRecordJsonPath 
-- @param self
-- @param #bool record
        
--------------------------------
-- 
-- @function [parent=#NodeReader] destroyInstance 
-- @param self
        
--------------------------------
-- 
-- @function [parent=#NodeReader] NodeReader 
-- @param self
 

	
--------------------------------
-- @function [parent=#NodeReader] getInstance 
-- @param self
-- @return NodeReader#NodeReader ret (return value: ccs.NodeReader)



return nil
