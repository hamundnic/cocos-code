
--------------------------------
-- @module ToggleVisibility
-- @extend ActionInstant
-- @parent_module cc

--------------------------------
--  Allocates and initializes the action 
-- @function [parent=#ToggleVisibility] create 
-- @param self
-- @return ToggleVisibility#ToggleVisibility ret (return value: cc.ToggleVisibility)
        
--------------------------------
-- 
-- @function [parent=#ToggleVisibility] clone 
-- @param self
-- @return ToggleVisibility#ToggleVisibility ret (return value: cc.ToggleVisibility)
        
--------------------------------
-- 
-- @function [parent=#ToggleVisibility] update 
-- @param self
-- @param #float time
        
--------------------------------
-- 
-- @function [parent=#ToggleVisibility] reverse 
-- @param self
-- @return ToggleVisibility#ToggleVisibility ret (return value: cc.ToggleVisibility)
        
return nil
