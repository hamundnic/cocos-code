
--------------------------------
-- @module TransitionSceneOriented
-- @extend TransitionScene
-- @parent_module cc

--------------------------------
--  creates a base transition with duration and incoming scene 
-- @function [parent=#TransitionSceneOriented] create 
-- @param self
-- @param #float t
-- @param #cc.Scene scene
-- @param #int orientation
-- @return TransitionSceneOriented#TransitionSceneOriented ret (return value: cc.TransitionSceneOriented)
        
return nil
