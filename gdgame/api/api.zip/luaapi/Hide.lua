
--------------------------------
-- @module Hide
-- @extend ActionInstant
-- @parent_module cc

--------------------------------
--  Allocates and initializes the action 
-- @function [parent=#Hide] create 
-- @param self
-- @return Hide#Hide ret (return value: cc.Hide)
        
--------------------------------
-- 
-- @function [parent=#Hide] clone 
-- @param self
-- @return Hide#Hide ret (return value: cc.Hide)
        
--------------------------------
-- 
-- @function [parent=#Hide] update 
-- @param self
-- @param #float time
        
--------------------------------
-- 
-- @function [parent=#Hide] reverse 
-- @param self
-- @return ActionInstant#ActionInstant ret (return value: cc.ActionInstant)
        
return nil
