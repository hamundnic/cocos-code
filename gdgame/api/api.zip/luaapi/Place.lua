
--------------------------------
-- @module Place
-- @extend ActionInstant
-- @parent_module cc

--------------------------------
--  creates a Place action with a position 
-- @function [parent=#Place] create 
-- @param self
-- @param #vec2_table pos
-- @return Place#Place ret (return value: cc.Place)
        
--------------------------------
-- 
-- @function [parent=#Place] clone 
-- @param self
-- @return Place#Place ret (return value: cc.Place)
        
--------------------------------
-- 
-- @function [parent=#Place] update 
-- @param self
-- @param #float time
        
--------------------------------
-- 
-- @function [parent=#Place] reverse 
-- @param self
-- @return Place#Place ret (return value: cc.Place)
        
return nil
