
--------------------------------
-- @module RemoveSelf
-- @extend ActionInstant
-- @parent_module cc

--------------------------------
--  create the action 
-- @function [parent=#RemoveSelf] create 
-- @param self
-- @return RemoveSelf#RemoveSelf ret (return value: cc.RemoveSelf)
        
--------------------------------
-- 
-- @function [parent=#RemoveSelf] clone 
-- @param self
-- @return RemoveSelf#RemoveSelf ret (return value: cc.RemoveSelf)
        
--------------------------------
-- 
-- @function [parent=#RemoveSelf] update 
-- @param self
-- @param #float time
        
--------------------------------
-- 
-- @function [parent=#RemoveSelf] reverse 
-- @param self
-- @return RemoveSelf#RemoveSelf ret (return value: cc.RemoveSelf)
        
return nil
