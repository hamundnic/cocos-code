
--------------------------------
-- @module MaskSprite
-- @extend Sprite
-- @parent_module gd

--------------------------------
-- @function [parent=#MaskSprite] setMask 
-- @param self
-- @param #string str
-- @param #string str
-- @param #string str
        
--------------------------------
-- @overload self, char         
-- @overload self         
-- @function [parent=#MaskSprite] create
-- @param self
-- @param #char char
-- @return MaskSprite#MaskSprite ret (retunr value: gd.MaskSprite)

--------------------------------
-- @function [parent=#MaskSprite] testBindingIsOK 
-- @param self
        
return nil
